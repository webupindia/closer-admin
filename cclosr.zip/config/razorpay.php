<?php
return [
    /*
     * Specify the Private AUTH KEY in your .env file provided
     * by RazorPay in the API & Credential's section
     * of your account's integration page.
     * TEST:    
     * PRODUCTION:  
     */
    'secretKey' => 'PvO9AV7XLSL8nL7OJL4MR5TQ',
    /*
     * Specify the Private SALT in your .env file provided
     * by RazorPay in the API & Plugin's section
     * of your account's integration page.
     * TEST:    
     * PRODUCTION:  
     */
    'keyId' => 'rzp_test_FrAWhMjoCRQbPA',
    /*
     *Link for the api. For test it will be https://test.RazorPay.com  
     * and https://api.RazorPay.com is for production
     * TEST:        https://test.razorPay.com
     * PRODUCTION:  https://api.razorpay.com/v1
     */
    'apiUrl' => 'https://api.razorpay.com/v1',
    /*
     * Notification URL for server-server communication. 
     * Useful when user's connection drops while re-directing (max-len 500) 
     * notifyUrl should be an https URL
     */
    'notifyUrl' => config('app.url').'/webhook-razorpay',
     /*
    |--------------------------------------------------------------------------
    | Razorpay Webhook Secret.
    |--------------------------------------------------------------------------
    | The webhook secret key on the dashboard 
    | to be used for Payment response
    |
    */
    'webhook_secret' => '',
];