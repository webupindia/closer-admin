<?php

namespace App\Models\Friend;

use Illuminate\Database\Eloquent\Model;

class CloserRequestCount extends Model
{
    protected $table = 'closer_request_count';
}
