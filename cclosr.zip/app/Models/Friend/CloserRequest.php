<?php

namespace App\Models\Friend;

use App\Models\User;
use App\Models\Template\Template;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CloserRequest extends Model
{
    use SoftDeletes;
    protected $table = 'closer_request';

    /**
     * Each Sender Id belongs to User.
     *
     */
    public function sender()
    {
      return $this->belongsTo(User::class,'sender_id');
    }

     /**
     * Each Receiver Id belongs to User.
     *
     */
    public function receiver()
    {
      return $this->belongsTo(User::class,'receiver_id');
    }

     /**
     * Each template belongs to Template table.
     *
     */
    public function template()
    {
      return $this->belongsTo(Template::class,'template_id');
    }
     
}
