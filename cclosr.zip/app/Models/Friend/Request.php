<?php

namespace App\Models\Friend;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class Request extends Model
{
    protected $table = 'friend_request';

    /**
     * Each Sender Id belongs to User.
     *
     */
    public function sender()
    {
      return $this->belongsTo(User::class,'sender_id');
    }

     /**
     * Each Receiver Id belongs to User.
     *
     */
    public function receiver()
    {
      return $this->belongsTo(User::class,'receiver_id');
    }
}
