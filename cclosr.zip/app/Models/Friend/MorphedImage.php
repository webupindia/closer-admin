<?php

namespace App\Models\Friend;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class MorphedImage extends Model
{
    protected $table = 'morphed_images';

    /**
     * Each Sender Id belongs to User.
     *
     */
    public function sender()
    {
      return $this->belongsTo(User::class,'sender_id');
    }

     /**
     * Each Receiver Id belongs to User.
     *
     */
    public function receiver()
    {
      return $this->belongsTo(User::class,'user_id');
    }
}
