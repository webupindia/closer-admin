<?php

namespace App\Models\Membership;

use Illuminate\Database\Eloquent\Model;

class MembershipPlan extends Model
{
    protected $table = 'membership_plan';

     public function scopeHaveId($query, $id)
        {
            return $query->where('id', $id);
        }
}
