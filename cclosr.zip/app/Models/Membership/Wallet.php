<?php

namespace App\Models\Membership;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;


class Wallet extends Model
{
    protected $table = 'membership_credits';

    /* Wallet point belongs to the user */
    public function member()
    {
    	return $this->belongsTo(User::class,'user_id');
    }
}
