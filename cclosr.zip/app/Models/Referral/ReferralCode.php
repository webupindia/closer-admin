<?php

namespace App\Models\Referral;

use Illuminate\Database\Eloquent\Model;

class ReferralCode extends Model
{
    protected $table = 'referral_code';

    /**
        * Scope a query to only include users of a given id.
        *
        * @param  \Illuminate\Database\Eloquent\Builder  $query
        * @param  mixed  $type
        * @return \Illuminate\Database\Eloquent\Builder
        */
       public function scopeUser($query, $id)
       {
           return $query->where('user_id', $id);
       }

        /**
        * Scope a query to only include users of a given referral.
        *
        * @param  \Illuminate\Database\Eloquent\Builder  $query
        * @param  mixed  $type
        * @return \Illuminate\Database\Eloquent\Builder
        */
       public function scopeCode($query, $code)
       {
           return $query->where('code', $code);
       }
}
