<?php

namespace App\Models\Referral;

use Illuminate\Database\Eloquent\Model;

class ReferralUsed extends Model
{
    protected $table = 'referral_used';

    /**
         * Scope a query to only include users of a given id.
         *
         * @param  \Illuminate\Database\Eloquent\Builder  $query
         * @param  mixed  $type
         * @return \Illuminate\Database\Eloquent\Builder
         */
        public function scopeUser($query, $id)
        {
            return $query->where('sender_id', $id);
        }
}
