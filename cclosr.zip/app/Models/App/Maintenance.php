<?php

namespace App\Models\App;

use Illuminate\Database\Eloquent\Model;

class Maintenance extends Model
{
    protected $table = 'maintenance';
     /* Status : 1 Maintenance Mode On
     * Status : 0 Maintenance Mode Off
     */
    protected $fillable = [
        'status'
    ];
}
