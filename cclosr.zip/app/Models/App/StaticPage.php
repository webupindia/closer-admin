<?php

namespace App\Models\App;

use Illuminate\Database\Eloquent\Model;

class StaticPage extends Model
{
    protected $table = 'static_pages';

    protected $fillable = [
        'title','type','content','status'
    ];

    public function scopeHaveId($query, $id)
    {
        return $query->where('id', $id);
    }
}
