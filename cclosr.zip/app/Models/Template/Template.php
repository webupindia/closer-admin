<?php

namespace App\Models\Template;

use Illuminate\Database\Eloquent\Model;

class Template extends Model
{

    protected $table = 'photo_template';

    public function scopeHaveId($query, $id)
        {
            return $query->where('id', $id);
        }
}
