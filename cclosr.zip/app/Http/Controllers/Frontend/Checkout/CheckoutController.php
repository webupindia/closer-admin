<?php

namespace App\Http\Controllers\Frontend\Checkout;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Membership\MembershipPlan;
use Illuminate\Support\Facades\Crypt;

class CheckoutController extends Controller
{
  public function index($id)
  {
     try {
         $decrypted    = Crypt::decrypt($id);
         $getResult    = MembershipPlan::where('id',$decrypted)->first();

         if(!is_null($getResult)){
          return view('frontend.checkout.index',['getResult'=>$getResult]);
         } 
          smilify('error', 'Something went wrong!!🙁 Please Try again.');
          return redirect()->back();

     } catch (\Exception $e) {
      smilify('error', 'User edit page not found 🙁 . Please Try again.');
      return redirect()->back();
     }
  }
   
}