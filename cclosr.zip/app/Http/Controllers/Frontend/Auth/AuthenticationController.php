<?php

namespace App\Http\Controllers\Frontend\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Contracts\Hashing\Hasher as HasherContract;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Password;
use Laravel\Socialite\Facades\Socialite;
use App\Models\PasswordReset;
use App\Models\User;
use Carbon\Carbon;
use App\Http\Requests\PasswordRequest;

class AuthenticationController extends Controller
{
    protected $hasher;
    public function __construct(HasherContract $hasher)
     {
        $this->hasher = $hasher;
     }
    public function index()
    {
       if (Auth::check()) {
         return redirect(route('get.index'));
       } else{
         return view('frontend.auth.login');
       }
    }
     //Google login
     public function redirectToGoogle()
     {
         return Socialite::driver('google')->redirect();
     }
     
     public function handleGoogleCallback()
     {
         $user = Socialite::driver('google')->user();
 
        $this->_registerOrLoginUser($user);
        //Return home after login
        return redirect()->route('home');
     }
 
     //Facebook login
       public function redirectToFacebook()
       {
           return Socialite::driver('facebook')->redirect();
       }
 
       public function handleFacebookCallback()
       {
           $user = Socialite::driver('facebook')->user();
            $this->_registerOrLoginUser($user);
            //Return home after login
            return redirect()->route('home');
       }
       protected function _registerOrLoginUser($data)
       {
          $user = User::where('email','=',$data->email)->first();
          $status = '1';
           if(!$user)
           {
               $user = new User();
               $user->name       = $data->name;
               $user->email      = $data->email;
               $user->status      = $status;
               $user->provider_id = $data->id;
               $user->avatar     = $data->avatar;
               $user->save();
   
           }
               Auth::login($user);
       } 
/* Post: Login into User */
    public function postLogin(Request $request)
    {
        $this->validate($request, [
            'email'     => 'required|email|max:255',
            'password'  => 'required|min:8'
        ]);

        $email          = $request['email'];
        $password       = $request['password'];
        $email_check    = User::where('email',$email)->first();     
        $user_check     = User::where('active', '=', '1')
                          ->whereNull('registeration_type')
                          ->where('email_verification', '=', '1')
                          ->first();
        if(!$email_check)
        {
            notify()->error('🙁 Invalid Your Email Id.');
            return redirect()->back();
        }
        if(!$user_check)
        {
            notify()->error('🙁 Your ID has been deactivated. Please contact administration.');
            return redirect()->back();
        }
        if (Auth::attempt([
            'email'    => $email, 
            'password' => $password, 
            'active'   => '1', 
             'email_verification' => '1', 
            ]))
        {
            notify()->success('😊 Logged In Successfully.');
            return redirect()->intended('/home');
        }
        else {
            notify()->error('🙁 Something Went Wrong ! Try Again');
            return redirect()->back();
        }
    }
/*----Start Forget Password-----*/    
    // Reset Link Request
    public function broker()
    {
        return Password::broker();
    }

    public function forget(Request $request)
    {
        //for save on POST request
        if ($request->isMethod('post')) 
        {
             $this->validate($request, [
                'email' => 'required|email',
             ]);

             $user = User::where('email', $request->get('email'))->first();
             if(!$user)
              {
                notify()->error('🙁 Your Account not found!!');  
                return redirect()->back();
              }
             $response = $this->broker()->sendResetLink(
                $request->only('email')
             );

            if(Password::RESET_LINK_SENT)
             {
               notify()->success('😊 A mail has been send to your e-mail address. Follow the given instruction to reset your password!!');    
               return redirect()->back();
             }
             notify()->error('🙁 Password reset link could not send! Try Again!!');  
             return redirect()->back();
        }
        return view('frontend.auth.forget-password');
    }

/*----Reset Password-----*/    
        public function reset(Request $request, $token)
      {
        //for save on POST request
        if ($request->isMethod('post')) 
        {
            $this->validate($request, [
                'token' => 'required',
                'email' => 'required|email',
                'password' => 'required|min:8|max:50',
                'password_confirmation' =>'required|required_with:password|same:password',
            ]);

            $token = $request->get('token');
            $email = $request->get('email');
            $password = $request->get('password');
            $reset = PasswordReset::where('email', $email)->first();
            if($reset)
             {
                //token expiration checking, allow 24 hrs only
                $today =  Carbon::now(env('APP_TIMEZONE','Asia/Dhaka'));
                $createdDate = Carbon::parse($reset->created_at);
                $hoursGone = $today->diffInHours($createdDate);
                if($this->hasher->check($token, $reset->token) && $hoursGone <= 24)
                 {
                    $user = User::where('email', '=', $email)->first();
                    $user->password = bcrypt($password);
                    $user->save();
                    $reset->delete();
                    notify()->success('😊 Password successfully reset. Login now!!');  
                    return redirect()->route('user.get.login'); 
                 }
              }
                 notify()->error('🙁 User not found with this mail or token invalid or expired!!');  
                return redirect()->back();
        }
          return view('frontend.auth.reset-password', compact('token'));
      }

/*Get: Logout User */
     public function getLogout()
     {
         Auth::logout();
         Session::flush();
         notify()->success('We will Miss You 😭 Logged Out Successfully');
         return redirect()->route('get.index');
     }
}
