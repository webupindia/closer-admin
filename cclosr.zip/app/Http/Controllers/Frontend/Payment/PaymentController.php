<?php

namespace App\Http\Controllers\Frontend\Payment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Razorpay\Api\Api;
use Mail;
use Response;
use App\Models\Membership\MembershipPlan;
use App\Models\Transactions\Transactions;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use App\Models\Membership\Wallet;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PaymentController extends Controller
{

    public function Initiate(Request $request)
    {
        $this->validate($request, [
            'amount'      => 'required|integer|gt:0', 
            'credit'      => 'required|integer|gt:0', 
          ]);

        $amount  = strip_tags($request['amount']);
        $credit  = strip_tags($request['credit']);
        
        $receiptId = Str::random(20); // Generate random receipt id

        // Create an object of razorpay
        $api = new Api(config('razorpay.keyId'), config('razorpay.secretKey'));

        // In razorpay you have to convert rupees into paise we multiply by 100
        // Currency will be INR
        // Creating order
        $order = $api->order->create(array(
            'receipt' => $receiptId,
            'amount' => $amount * 100,
            'currency' => 'INR'
            )
        );

        // Return response on payment page
        $response = [
            'orderId' => $order['id'],
            'razorpayId' => config('razorpay.keyId'),
            'amount' => $amount * 100,
            'credit' => $credit,
            'currency' => 'INR',
            'description' => 'Testing description',
        ];

        // Let's checkout payment page is it working
        return view('frontend.payment.index',compact('response'));
    }

    public function Complete(Request $request)
{
 
    try {
        $signatureStatus = $this->SignatureVerify(
            $request['rzp_signature'],
            $request['rzp_paymentid'],
            $request['rzp_orderid']
        );
        $transactionId = $request['rzp_paymentid'];
        if($signatureStatus == true)
        {
            $userId    = Auth::user()->id;
            $planId    = session('planId');
            $getResult = MembershipPlan::where('id',$planId)->first();
            $amount    = is_null($getResult)?:$getResult->amount;
            $credit    = is_null($getResult)?:$getResult->credit;
            /* Check for refresh */
            $walletCheck  =   Wallet::where('transaction_id',$transactionId)->count();
            if($walletCheck>1)
            {
                return view('frontend.payment.success',['transactionId' => $transactionId,'amount'=>$amount]);
            } 
            $creditAmount   = Wallet::Where('user_id', $userId)->sum('credit');
            $debitAmount    = Wallet::Where('user_id', $userId)->sum('debit');
            $currentBalance = $creditAmount - $debitAmount;
            $newBalance     = round(($credit + $currentBalance),2);
            $membershipCredits = new Wallet();
            $membershipCredits->user_id           = $userId;
            $membershipCredits->credit            = $credit;
            $membershipCredits->debit             = "-";
            $membershipCredits->available_credit  = $newBalance;
            $membershipCredits->purpose           = "Added ".$credit." credits with transaction id".$transactionId;
            $membershipCredits->transaction_id    =  $transactionId;
            if($membershipCredits->save()) 
            {
                $subjectHeader    = "Added ".$credit." credits ::" .$transactionId. " To Your Ccloser Wallet";
                $userEmail        = Auth::user()->email;
                $username         = Auth::user()->username;
                Mail::send('frontend.email.credit', ['wallet_balance' => $newBalance,'amount' => $amount,'transaction_id' => $transactionId,'credit' => $credit,'username'=>$username], function ($message) use($userEmail,$subjectHeader)
                {
                   $message->to($userEmail)->from('ashwini.synapsesolution@gmail.com', 'Ccloser')->subject($subjectHeader);    
                });
                return view('frontend.payment.success',['transactionId' => $transactionId,'amount'=>$amount]);
            }
            return view('frontend.payment.failure');
        }
        return view('frontend.payment.failure');
        }
        catch(SignatureVerificationError $e)
        {
            return view('frontend.payment.failure');
        }
        catch(Exception $e) {
            return view('frontend.payment.failure');
        }
}

    // In this function we return boolean if signature is correct
    private function SignatureVerify($_signature,$_paymentId,$_orderId)
    {
        try
        {
            // Create an object of razorpay class
            $api = new Api(config('razorpay.keyId'), config('razorpay.secretKey'));
            $attributes  = array('razorpay_signature'  => $_signature,  'razorpay_payment_id'  => $_paymentId ,  'razorpay_order_id' => $_orderId);
            $order  = $api->utility->verifyPaymentSignature($attributes);
            return true;
        }
        catch(\Exception $e)
        {
            // If Signature is not correct its give a excetption so we use try catch
            return false;
        }
    }
}
