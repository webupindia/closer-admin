<?php

namespace App\Http\Controllers\Frontend\Contact;
use Mail;
use Response;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function index()
    {
         return view('frontend.contact-us.index');
    }
    public function sendMailContact(Request $request)
    {
        $validatedData = $request->validate([
        'name'      => 'required',
        'email'     => 'required|email',
        'phone'     => 'required',
        'company'   => 'required',
        'message'   => 'required',
        ]);
        
        $data= array(
                    'name'         => $request['name'],
                    'email'        => $request['email'],
                    'phone'        => $request['phone'],
                    'company'      => $request['company'],
                    'message'      => $request['message'],
                   );
        \Mail::send('frontend.email.contact', ['user' => $data], function ($message) use($data)
        {
            $message->to('amitu0238@gmail.com');
            $message->bcc('ashwini.synapsesolution@gmail.com');
            $message->subject('Contact Us From Ccloser Website');
            $message->from($data['email'], $data['name']);
        });

        if (\Mail::failures())
        {
            notify()->error('Oops! Something Went Wrong!!');  
            return redirect()->back();
        }
        else
        {
            notify()->success('Your Message has been sent!!');  
            return redirect()->back();
           
        }
    }
    
}
