<?php

namespace App\Http\Controllers\Frontend\Membership;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Membership\MembershipPlan;

class MembershipPlanController extends Controller
{
    public function index()
    {
        $membershipPlan = MembershipPlan::latest()
                           ->where('status','1')
                           ->get();
         return view('frontend.membership-plan.index',['membershipPlan'=>$membershipPlan]);
     }
     
}
