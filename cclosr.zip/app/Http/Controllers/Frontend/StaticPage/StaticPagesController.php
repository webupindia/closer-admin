<?php

namespace App\Http\Controllers\Frontend\StaticPage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\App\StaticPage;

class StaticPagesController extends Controller
{
    // public function index()
    // {
    //     $termsConditions = StaticPage::where('status','1')->where('type','about-us')->get();
    //      return view('frontend.include.footer',['termsConditions'=>$termsConditions]);
    //  }

     public function StaticSpecificData($slug)
     {
         $SpecificData = StaticPage::where('type',$slug)->first();
  
         if(!is_null($SpecificData)){
  
         return view('frontend.static-pages.index',['SpecificData'=>$SpecificData]);
  
         } else {
  
          return redirect()->back();
         }
     }
}
