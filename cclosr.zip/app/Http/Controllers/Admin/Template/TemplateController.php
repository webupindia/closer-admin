<?php

namespace App\Http\Controllers\Admin\Template;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Template\Template;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Crypt;

class TemplateController extends Controller
{
    public function index()
    {
        $templates = Template::latest()->get();
         return view('admin.theme-template.index',['templates'=>$templates]);
     }

    public function create(Request $request)
    {
    	 $this->validate($request, [
                'name'   => 'required|min:3|unique:photo_template',
                'url'     => 'required|mimes:jpeg,jpg,png|max:5102', //|dimensions:max_width=1202,max_height=340
              ]);
          try {
		          	if($request->hasFile('url'))
		    	      {
  		            $fileName = time().rand(1,100).'.'.$request->url->extension();  
  		            $request->url->storeAs('template',$fileName, 'public');
  		            $url = $fileName;
		            }
    			    	  $result = new Template();
    			        $result->name = $request['name'];
    			        $result->url  = $url;

      			    if($result->save())
      			    {
      			        smilify('success', 'Theme Template Created Successfully 🔥');
      			        return redirect()->route('template.get.index');
      			    }
    		    } catch(\Exception $e) {
    		    	 smilify('error', $e->getMessage());
    		         return redirect()->back();
    		    }	
	  }
	        
    public function destroy($id)
     {
        try {
            $decrypted  = Crypt::decrypt($id);
            $deleteUser = Template::find($decrypted)->delete();
           if($deleteUser) {
            smilify('success', 'Template deleted Successfully 😊');
            return redirect()->route('template.get.index');
           }
        } catch (\Exception $e) {
            connectify('error', 'Ooops 🙁', $e->getMessage());
            return redirect()->back();
           }
     }

    public function activeTemplate($id)
    {
        try {
            $decrypted  = Crypt::decrypt($id);
            $activeUser = Template::haveId($decrypted)->update([
                'status' =>1
            ]);
            if($activeUser){
                smilify('success', 'Template activated Successfully 😊');
                return redirect()->back();
            }
            } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                
                connectify('error', 'Ooops 🙁', $e->getMessage());
                return redirect()->back();
            }
    }

    public function deactiveTemplate($id)
    {
        try {
            $decrypted      = Crypt::decrypt($id);
            $deactiveUser   = Template::haveId($decrypted)->update([
                'status' =>0
            ]);
            if($deactiveUser){
                smilify('success', 'Template deactivated Successfully');
                return redirect()->back();
            }
          } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
              
              connectify('error', 'Ooops 🙁', $e->getMessage());
              return redirect()->back();
          }
    }
}
