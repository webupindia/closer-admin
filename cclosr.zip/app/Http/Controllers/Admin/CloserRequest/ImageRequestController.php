<?php

namespace App\Http\Controllers\Admin\CloserRequest;

use App\Http\Controllers\Controller;
use App\Models\Friend\CloserRequest;
use Illuminate\Http\Request;

class ImageRequestController extends Controller
{
    /* Fetch all the image morphing request sent */
    public function index()
    {
        $getRequest = CloserRequest::with('sender','receiver','template')->get();
        return view('admin.ccloser-request.index',['getRequest'=>$getRequest]);
    }
}
