<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Models\App\Maintenance;
use App\Models\App\VersionControl;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Crypt;

class AppController extends Controller
{
  


     /**
     * Display the status for the status of the app.
     *
     * @return \Illuminate\Http\Response
     */
    public function getMaintenance()
    {
        $appMaintenance    = Maintenance::first();
        return view('admin.setting.maintenance',['appMaintenance'=>$appMaintenance]);
    }

     /**
     * Change the maintenance status for the app
     *
     * @return \Illuminate\Http\Response
     */
    public function storeMaintenance(Request $request)
    {
        $this->validate($request, [
            'status'     => 'required',
        ]);

        try {

        $status            = intval($request['status']);
       
        $appMaintenance    = Maintenance::first();
        if(!is_null($appMaintenance)) {

            $status   = $appMaintenance->update([
                'status'  => $status
            ]);

        } else {
                $status = new Maintenance();
                $status->status = 1;
                $status->save();
        }
       

         if($status) {
            connectify('success', 'Success 🎉', 'App Status Changed Successfully');
            return redirect()->back();
         } else {
            connectify('error', 'Ooops 🙁', 'Status Updation Failed');
            return redirect()->back();
         }

        } catch (\Exception $e) {
            connectify('error', 'Ooops 🙁', $e->getMessage());
            return redirect()->back();
        }
    }

     /**
     * Display the version control for the  app.
     *
     * @return \Illuminate\Http\Response
     */
    public function getVersion()
    {
        $version    = VersionControl::get();
        return view('admin.setting.version-control',['version'=>$version]);
    }

    /**
     * Change the App Version for the app
     *
     * @return \Illuminate\Http\Response
     */
    public function storeVersion(Request $request)
    {
        $this->validate($request, [
            'current_version'     => 'required',
            'upcoming_version'     => 'required',
            'platform'     => 'required',
        ]);

        try {
            $currentVersion     = strip_tags($request['current_version']);
            $upcoming_version   = strip_tags($request['upcoming_version']);
            $platform           = Crypt::decrypt($request['platform']);

            $app_version    = VersionControl::where('platform',$platform)->first();

            if(!is_null($app_version)) {
                
                $version = VersionControl::where('platform',$platform)->update([
                    'current_version'   => $currentVersion,
                    'upcoming_version'  => $upcoming_version,
                    'platform'          => $platform,
                ]);
                
            } else {
                $version = new VersionControl();

                $version->current_version   = $currentVersion;
                $version->upcoming_version  = $upcoming_version;
                $version->platform          = $platform;

                $version->save();
            }
            
            if($version) {
                connectify('success', 'Success 🎉', 'App Version Changed Successfully');
                return redirect()->back();
             } else {
                connectify('error', 'Ooops 🙁', 'Version Updation Failed');
                return redirect()->back();
             }

        } catch (\Exception $e) {
            connectify('error', 'Ooops 🙁', $e->getMessage());
            return redirect()->back();
        }
    }
}
