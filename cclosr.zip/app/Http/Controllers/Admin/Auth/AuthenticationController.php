<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Models\Admin\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use App\Http\Requests\PasswordRequest;

class AuthenticationController extends Controller
{
    /**
     * Login Admin and redirect to home
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
       if (Auth::guard('admin')->user()) 
       {
         return redirect(route('admin.get.home'));
       }
      else
       {
            return view('admin.auth.login');
       }
    }

    /* Post: Login into Admin Panel */
    public function postLogin(Request $request)
    {
        $this->validate($request, [
            'email'     => 'required|email|max:255',
            'password'  => 'required|min:8'
        ]);

        $email          = $request['email'];
        $password       = $request['password'];
        $email_check    = Admin::where('email',$email)->first();

        if(!$email_check)
        {
            connectify('error', 'Ooops 🙁', 'Invalid Email Id.');
            return redirect()->back();
        }

        if (Auth::guard('admin')->attempt(['email' => $email, 'password' => $password]))
        {
            connectify('success', 'Welcome 😊', 'Logged In Successfully');
            return redirect()->intended('admin/home');
        }
        else {
            connectify('error', 'Ooops 🙁', 'Something Went Wrong. Try Again');
            return redirect()->back();
        }
    }
     /* Post: Change admin Password */
     public function changePassword(Request $request)
     {
         $this->validate($request, [
             'old_password'  => 'required|min:8',
             'password'      => 'required|min:8',
             'password_confirmation' =>'required|required_with:password|same:password',
         ]);
 
         $password           = bcrypt($request['password']);
         $user_email         = Auth::guard('admin')->user()->email;
         $user               = Admin::where('email', $user_email)->first(); //get Admin data
         $existingpassword   = Hash::check($request['old_password'], $user->password); //check password
 
         if($existingpassword)
         {
             $update         = Admin::where('email',$user_email)->update(['password' => $password,]);

            connectify('success', 'Success 🎉', 'Password Changed Successfully');
            Auth::logoutOtherDevices($password);
            Session::flush();
            return redirect()->route('admin.get.index');
         } else {
            connectify('error', 'Ooops 🙁', 'Something Went Wrong. Try Again');
            return redirect()->back();
         }
     }
 
     /*Get: Logout Admin */
     public function getLogout()
     {
         Auth::logout();
         Session::flush();
         connectify('success', 'We will Miss You 😭', 'Logged Out Successfully');
         return redirect()->route('admin.get.index');
     }

     /* Get admin profile page */
     public function getProfile()
     {
         return view('admin.auth.profile');
     }

     /* update admin email And Name*/
     public function update(Request $request)
     {
        $this->validate($request, [
            'name'  => 'required',
            'email'  => 'required|email',
        ]);
        try {
            $email = strip_tags($request['email']);
            $name = strip_tags($request['name']);
            $updateEmail = Admin::where('id',Auth::guard('admin')->user()->id)
            ->update(['name' => $name, 'email' => $email]);
            if($updateEmail) {
                Auth::logout();
                Session::flush();
                connectify('success', 'Success 🎉', 'Email Changed Successfully.Use new email to login');
                return redirect()->route('admin.get.index');
            }
            connectify('error', 'Ooops 🙁', 'Something Went Wrong. Try Again');
            return redirect()->back();
            
        } catch (\Exception $e) {
            connectify('error', 'Ooops 🙁', 'Something went wrong. Try Again');
            return redirect()->back();
        }
     }
}
