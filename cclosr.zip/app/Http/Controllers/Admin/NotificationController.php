<?php

namespace App\Http\Controllers\Admin;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;

class NotificationController extends Controller
{
    
    /* Get All Notifications */
    public function index()
    {
            $user      = Auth::guard('admin')->user();
            $getNotify = $user->unreadNotifications()->get();
            return view('admin.setting.notification',['getNotify'=>$getNotify]);
        
    }
    public function markAsRead($id)
    {
        try {
            $decrypted  = Crypt::decrypt($id);
            $update     = DB::table('notifications')->where('id', $decrypted)->update([
                'read_at' => Carbon::now()
                ]);
                if($update){
                    connectify('success', 'Success 🎉', 'Notifications marked as read.');
                    return redirect()->back();
                } else {
                    connectify('success', 'Success 🎉', 'All Notifications marked as read.');
                    return redirect()->route('admin.get.home');
                }
            
        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
            connectify('error', 'Ooops 🙁', 'Something went wrong. Try Again');
            return redirect()->back();
        }
        
    }

       public function markAllAsRead()
    {
    
      $user =Auth::guard('admin')->user();
      $user->unreadNotifications->markAsRead();

      connectify('success', 'Success 🎉', 'All Notifications marked as read.');
      return redirect()->route('admin.get.home');

    }

}
