<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use \Cache;

class HomeController extends Controller
{

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $data = Cache::remember('data', 30, function ()
        {
          return User::select(DB::raw('count(id) as user'),
                 DB::raw('YEAR(created_at) year, MONTH(created_at) month'))
                 ->groupby('year','month')
                 ->get();
        });
        $users = User::latest()->limit(5)->get();
        return view('admin.welcome',['users'=>$users,'data'=>$data]);
    }
   
}
