<?php

namespace App\Http\Controllers\Admin\ReportManagement;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Transactions\Transactions;
use Illuminate\Support\Facades\DB;
use \Cache;

class MonthlyTransactionController extends Controller
{
    public function index()
    {
       $data = Cache::remember('data', 30, function ()
        {
          return Transactions::select(DB::raw('sum(amount) as amount'),
                 DB::raw('YEAR(created_at) year, MONTH(created_at) month'))
                 ->groupby('year','month')
                 ->get();

        });
        $transactions = Transactions::latest()->limit(5)->get();
        return view('admin.report-management.monthly-transactions',['transactions'=>$transactions,'data'=>$data]);
    }
}
