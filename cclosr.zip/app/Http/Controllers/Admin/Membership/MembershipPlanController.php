<?php

namespace App\Http\Controllers\Admin\Membership;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Membership\MembershipPlan;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Crypt;

class MembershipPlanController extends Controller
{
   public function index()
    {
        $memberships = MembershipPlan::latest()->get();
         return view('admin.membership.membership-plan.index',['memberships'=>$memberships]);
     }
/**/
     public function create(Request $request)
    {
       $this->validate($request, [
                'amount'   => 'required',
                'credit'     => 'required',
              ]);
          try {
                  $result = new MembershipPlan();
                  $result->amount = $request['amount'];
                  $result->credit = $request['credit'];

                if($result->save())
                {
                    smilify('success', 'Membership Plan Created Successfully 🔥');
                    return redirect()->route('membership-plan.get.index');
                }
            } catch(\Exception $e) {
               smilify('error', $e->getMessage());
                 return redirect()->back();
            } 
      }
      
      public function edit($id)
      {
       try {
           $decrypted    = Crypt::decrypt($id);
           $getResult    = MembershipPlan::where('id',$decrypted)->first();

           if(!is_null($getResult)){
            return view('admin.membership.membership-plan.edit',['getResult'=>$getResult]);
           } 
         } catch (\Exception $e) {
          smilify('error', 'Something went wrong!!🙁 Please Try again.');
          return redirect()->back();
         }
      }

    public function update(Request $request)
    {
        $this->validate($request, [
                'amount'   => 'required',
                'credit'   => 'required', 
         ]);
                $id        = Crypt::decrypt($request['id']);
                $amount    = strip_tags($request['amount']);
                $credit    = strip_tags($request['credit']);
              
                $update  = MembershipPlan::where('id',$id)->update([
                'amount'     => $amount,
                'credit'     => $credit,
               ]);
 
        if($update){
            smilify('success', 'Membership Plan Updated Successfully 😊');
            return redirect()->route('membership-plan.get.index');
        } 
        smilify('error', 'Something went wrong!!🙁 Please Try again.');
        return redirect()->back();
        
    }

      public function destroy($id)
     {
        try {
            $decrypted  = Crypt::decrypt($id);
            $deleteUser = MembershipPlan::find($decrypted)->delete();
           if($deleteUser) {
            smilify('success', 'Membership Plan deleted Successfully 😊');
            return redirect()->route('membership-plan.get.index');
           }
        } catch (\Exception $e) {
            connectify('error', 'Ooops 🙁', $e->getMessage());
            return redirect()->back();
           }
     }
     
     public function active($id)
    {
        try {
            $decrypted  = Crypt::decrypt($id);
            $activeUser = MembershipPlan::haveId($decrypted)->update([
                'status' =>1
            ]);
            if($activeUser){
                smilify('success', 'MembershipPlan activated Successfully 😊');
                return redirect()->back();
            }
            } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                
                connectify('error', 'Ooops 🙁', $e->getMessage());
                return redirect()->back();
            }
    }

    public function deactive($id)
    {
        try {
            $decrypted      = Crypt::decrypt($id);
            $deactiveUser   = MembershipPlan::haveId($decrypted)->update([
                'status' =>0
            ]);
            if($deactiveUser){
                smilify('success', 'MembershipPlan deactivated Successfully');
                return redirect()->back();
            }
          } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
              
              connectify('error', 'Ooops 🙁', $e->getMessage());
              return redirect()->back();
          }
    }
}
