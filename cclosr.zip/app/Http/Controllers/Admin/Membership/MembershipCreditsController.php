<?php

namespace App\Http\Controllers\Admin\Membership;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Membership\Wallet;
use App\Models\User;
use Illuminate\Support\Facades\Crypt;

class MembershipCreditsController extends Controller
{
    public function index()
    {
        $getRequest = Wallet::with('member')->get();
         return view('admin.membership.membership-credits.index',['getRequest'=>$getRequest]);
     }
    public function show($id)
    {
        try {
            $decrypted = Crypt::decrypt($id);
            $SpecificUser = Wallet::where('id',$decrypted)->get();
            return view('admin.membership.membership-credits.show',['SpecificUser'=>$SpecificUser]);
        } catch (\Exception $e) {
            smilify('error', 'Something went wrong!!🙁 Please Try again.');
            return redirect()->back();
        }
       
    }
}
