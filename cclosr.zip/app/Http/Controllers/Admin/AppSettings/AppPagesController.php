<?php

namespace App\Http\Controllers\Admin\AppSettings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\App\StaticPage;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str;

class AppPagesController extends Controller
{
	public function index()
    {
        $AppPages = StaticPage::latest()->get();
        return view('admin.setting.app-pages.index',['AppPages'=>$AppPages]);
      
    }
    public function show($id)
    {
        try {
            $decrypted = Crypt::decrypt($id);
            $SpecificUser = User::where('id',$decrypted)->first();

            /* Fetch all the friends request sent by the user */
            $getFriends = FriendRequest::where('sender_id',$decrypted)->with('receiver')->get();
            $getCloserRequestCount = CloserRequestCount::where('sender_id',$decrypted)->get();
            return view('admin.users.show',['SpecificUser'=>$SpecificUser,'getFriends' => $getFriends,'getCloserRequestCount'=>$getCloserRequestCount]);
        } catch (\Exception $e) {
            smilify('error', 'Something went wrong!!🙁 Please Try again.');
            return redirect()->back();
        }
       
    }
     public function create(Request $request)
    {
         $this->validate($request, [
                'title'             => 'required|unique:static_pages',
                'content'           => 'required',
              ]);

            $result = new StaticPage();
            $result->title               = $request['title'];
            $result->content             = $request['content'];
            $result->status              = 1;
            $result->type                = Str::slug( $result->title);
         if($result->save())
            {
                smilify('success', 'Static Page Created Successfully 🔥');
                return redirect()->route('app-page.get.index');
            }
            else
            { 
                smilify('error', 'Something went wrong!!🙁 Please Try again.');
                return redirect()->back();
            } 
    }
    public function edit($id)
    {
       try {
           $decrypted    = Crypt::decrypt($id);
           $getResult    = StaticPage::where('id',$decrypted)->first();

           if(!is_null($getResult)){
            return view('admin.setting.app-pages.edit',['getResult'=>$getResult]);
           } 
            smilify('error', 'Something went wrong!!🙁 Please Try again.');
            return redirect()->back();

       } catch (\Exception $e) {
        smilify('error', 'Static Page edit page not found 🙁 . Please Try again.');
        return redirect()->back();
       }
    }

    public function update(Request $request)
    {
        $this->validate($request, [
                'title'              => 'required',
                'type'               => 'required',
                'content'            => 'required',
         ]);
         try {
                $id                 = Crypt::decrypt($request['id']);
                $title              = strip_tags($request['title']);
                $type               =  strip_tags($request['type']);
                $content            = $request['content'];

                $updateUser  = StaticPage::where('id',$id)->update([
                'title'             => $title,
                'type'              => $type,
                'content'           => $content,
               ]);
 
            if($updateUser){
                smilify('success', 'App Page Updated Successfully 😊');
                return redirect()->route('app-page.get.index');
            } 
       } catch (\Exception $e) {
        connectify('error', 'Ooops 🙁', $e->getMessage());
        return redirect()->back();
       }

    }
    public function destroy($id)
     {
        try {
            $decrypted  = Crypt::decrypt($id);
            $delete = StaticPage::find($decrypted)->delete();
           if($delete) {
            smilify('success', 'App Page deleted Successfully 😊');
            return redirect()->route('app-page.get.index');
           }
        } catch (\Exception $e) {
            connectify('error', 'Ooops 🙁', $e->getMessage());
            return redirect()->back();
           }
     }

          /**
     * Activate a specific user.
     *
     * @param  \App\User  $id
     * @return \Illuminate\Http\Response
     */
    public function active($id)
    {
        try {
            $decrypted  = Crypt::decrypt($id);
            $active = StaticPage::haveId($decrypted)->update([
                'status' =>1
            ]);
            if($active){
                smilify('success', 'Page activated Successfully 😊');
                return redirect()->back();
            } else {
                connectify('error', 'Ooops 🙁', 'Something went wrong');
                return redirect()->back();
            }
           
        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
            
            connectify('error', 'Ooops 🙁', $e->getMessage());
            return redirect()->back();
        }
    }

     /**
     * Deactivate a specific user.
     *
     * @param  \App\User  $id
     * @return \Illuminate\Http\Response
     */
    public function deactive($id)
    {
        try {
            $decrypted      = Crypt::decrypt($id);
            $deactive   = StaticPage::haveId($decrypted)->update([
                'status' =>0
            ]);
            if($deactive){
                smilify('success', 'Page deactivated Successfully');
                return redirect()->back();
            } else {
                connectify('error', 'Ooops 🙁', 'Something went wrong');
                return redirect()->back();
            }
           
        } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
            
            connectify('error', 'Ooops 🙁', $e->getMessage());
            return redirect()->back();
        }
    }


}
