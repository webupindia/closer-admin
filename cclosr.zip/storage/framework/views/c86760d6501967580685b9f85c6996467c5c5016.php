<!--footer section start-->
<footer class="footer-section">
    <!--footer top start-->
    <div class="footer-top gradient-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-12">
                    <div class="footer-nav-wrap text-white mb-0 mb-md-4 mb-lg-0">
                        <a class="d-block" href="#"><img src="<?php echo e(asset('frontend/img/logo-white.png')); ?>" alt="footer logo" width="150" class="img-fluid mb-1"></a>
                        <p>Intrinsicly matrix high standards in niches whereas intermandated niche markets. Objectively harness competitive resources.</p>
                        <ul class="list-unstyled social-list mb-0">
                            <li class="list-inline-item"><a href="#" class="rounded"><span class="ti-facebook white-bg color-2 shadow rounded-circle"></span></a></li>
                            <li class="list-inline-item"><a href="#" class="rounded"><span class="ti-twitter white-bg color-2 shadow rounded-circle"></span></a></li>
                            <li class="list-inline-item"><a href="#" class="rounded"><span class="ti-linkedin white-bg color-2 shadow rounded-circle"></span></a></li>
                            <li class="list-inline-item"><a href="#" class="rounded"><span class="ti-dribbble white-bg color-2 shadow rounded-circle"></span></a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-2 col-md-4 col-6">
                    <div class="footer-nav-wrap text-white">
                        <h5 class="text-white">Usefull Links</h5>
                        <ul class="list-unstyled footer-nav-list mt-3">
                        <?php
                          $termsConditions=DB::table('static_pages')->where('status','1')->orderBy('id', 'asc')->get();
                        ?>
                            <?php $__currentLoopData = $termsConditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('get.static.page',['slug'=>$items->type])); ?>" class="text-foot"><span class="ti-angle-double-right"></span> <?php echo e($items->title); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-2 col-md-4 col-6">
                    <div class="footer-nav-wrap text-white">
                        <h5 class="text-white">Company</h5>
                        <ul class="list-unstyled footer-nav-list mt-3">
                            <li><a href="<?php echo e(url('/')); ?>" class="text-foot"><span class="ti-angle-double-right"></span> Home</a></li>
                            <li><a href="<?php echo e(route('get.membership.index')); ?>" class="text-foot"><span class="ti-angle-double-right"></span> Membership plan</a></li>
                            <li><a href="<?php echo e(route('get.contact.index')); ?>" class="text-foot"><span class="ti-angle-double-right"></span> Contact us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-12">
                    <div class="footer-nav-wrap text-white">
                        <h5 class="text-light footer-head">Newsletter</h5>
                        <p>Subscribe our newsletter to get our update. We don't send span email to you.</p>
                        <form action="#" class="newsletter-form mt-3">
                            <div class="input-group">
                                <input type="email" class="form-control" id="subscribe-email" placeholder="Enter your email" required="">
                                <div class="input-group-append">
                                    <button class="btn solid-btn subscribe-btn btn-hover" type="submit">
                                        Subscribe
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--footer top end-->

    <!--footer copyright start-->
    <div class="footer-bottom gradient-bg py-3">
        <div class="container">
            <div class="row text-center justify-content-center">
                <div class="col-md-6 col-lg-5 text-light font-weight-bold"><p class="copyright-text pb-0 mb-0">Copyrights © 2021. All
                    rights reserved by
                    <a href="#" target="_blank">Ccloser</a></p>
                </div>
            </div>
        </div>
    </div>
    <!--footer copyright end-->
</footer>
<!--footer section end--><?php /**PATH C:\xampp\htdocs\ccloser-admin\resources\views/frontend/include/footer.blade.php ENDPATH**/ ?>