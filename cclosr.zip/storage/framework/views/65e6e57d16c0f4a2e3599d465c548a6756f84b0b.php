<!-- BEGIN: Vendor JS-->
<script src="<?php echo e(asset('app-assets/vendors/js/vendors.min.js')); ?>"></script>
<!-- BEGIN Vendor JS-->

<!-- BEGIN: Page Vendor JS-->
<script src="<?php echo e(asset('app-assets/vendors/js/extensions/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/calendar/fullcalendar.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/calendar/extensions/daygrid.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/calendar/extensions/timegrid.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/calendar/extensions/interactions.min.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/pickers/pickadate/picker.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/pickers/pickadate/picker.date.js')); ?>"></script>
<!-- END: Page Vendor JS-->

<!-- BEGIN: Theme JS-->
<script src="<?php echo e(asset('app-assets/js/core/app-menu.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/js/core/app.js')); ?>"></script>
<script src="<?php echo e(asset('app-assets/js/scripts/components.js')); ?>"></script>
<?php echo notifyJs(); ?>
<!-- END: Theme JS-->

<!-- BEGIN: Page JS-->
    <?php echo $__env->yieldPushContent('vendor-script'); ?>
    <?php echo $__env->yieldPushContent('page-script'); ?>
<!-- END: Page JS--><?php /**PATH C:\xampp\htdocs\ccloser-admin\resources\views/admin/include/scripts.blade.php ENDPATH**/ ?>