
<?php $__env->startSection('title', 'Membership Plan '); ?>
<?php $__env->startSection('content'); ?>
<!--hero section start-->
    <section class="hero-section ptb-100 gradient-overlay-trns"
             style="background: url(<?php echo e(asset('frontend/img/hero-bg-4.jpg')); ?>)no-repeat center center / cover">
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-md-9 col-lg-7">
                    <div class="page-header-content text-white text-center pt-sm-5 pt-md-5 pt-lg-0">
                        <h1 class="text-white mb-0">Membership Plan</h1>
                        <div class="custom-breadcrumb">
                            <ol class="breadcrumb d-inline-block bg-transparent list-inline py-0">
                                <li class="list-inline-item breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                <li class="list-inline-item breadcrumb-item active">Membership Plan</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--hero section end-->
      <!--pricing section start-->
    <section id="pricing" class="pricing ptb-100 gray-light-bg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-9 col-lg-8">
                    <div class="section-heading mb-5 text-center">
                        <h2>Membership Plan</h2>
                        <p class="lead">Monotonectally mesh visionary supply chains before plug-and-play interfaces. Globally benchmark worldwide information after clicks-and-mortar channels.</p>
                    </div>
                </div>
            </div>
           
            <div class="row align-items-center  justify-content-between">
                <?php $__currentLoopData = $membershipPlan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-12 pb-4" >
                    <div class="card text-center single-pricing-pack">
                        <div class="pt-4"><h5>Membership Plan <?php echo e($loop->iteration); ?></h5></div>
                        <div class="card-header py-4 border-0 pricing-header">
                            <div class="h3 text-center mb-0">₹ <span class="price font-weight-bolder"> <?php echo e($item->amount); ?></span></div>
                        </div>
                        <div class="card-body">
                            <ul class="list-unstyled text-sm mb-4 pricing-feature-list">
                                <li><b><?php echo e($item->credit); ?> Credits</b></li>
                            </ul>
                            <a href="<?php echo e(route('get.checkout.index',['id'=>Crypt::encrypt($item->id)])); ?>" class="btn outline-btn mb-3">Purchase now</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </section>
    <!--pricing section end-->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ccloser-admin\resources\views/frontend/membership-plan/index.blade.php ENDPATH**/ ?>