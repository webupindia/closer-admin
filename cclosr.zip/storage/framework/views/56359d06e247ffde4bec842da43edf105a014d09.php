
<?php $__env->startSection('title',__('Home | Ccloser Admin')); ?>
<?php $__env->startPush('vendor-style'); ?>
        <!-- vendor css files -->
        <link rel="stylesheet" href="<?php echo e(asset('app-assets/vendors/css/charts/apexcharts.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('app-assets/vendors/css/extensions/tether-theme-arrows.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('app-assets/vendors/css/extensions/tether.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('app-assets/vendors/css/extensions/shepherd-theme-default.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page-style'); ?>
        <!-- Page css files -->
        <link rel="stylesheet" href="<?php echo e(asset('app-assets/css/pages/dashboard-analytics.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('app-assets/css/pages/card-analytics.css')); ?>">
  <?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section id="dashboard-analytics">
        <div class="row">
            <div class="col-lg-6 col-md-12 col-sm-12">
                <div class="card bg-analytics text-white">
                    <div class="card-content">
                        <div class="card-body text-center">
                            <img src="<?php echo e(asset('app-assets/images/elements/decore-left.png')); ?>" class="img-left" alt="
card-img-left">
                            <img src="<?php echo e(asset('app-assets/images/elements/decore-right.png')); ?>" class="img-right" alt="
card-img-right">
                            <div class="avatar avatar-xl bg-primary shadow mt-0">
                                <div class="avatar-content">
                                    <i class="feather icon-award white font-large-1"></i>
                                </div>
                            </div>
                            <div class="text-center">
                                <h1 class="mb-2 text-white">Congratulations Mr. Sanchit,</h1>
                                <p class="m-auto w-75">You have done <strong>57.6%</strong> more sales this week.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar bg-rgba-primary p-50 m-0">
                            <div class="avatar-content">
                                <i class="feather icon-users text-primary font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1 mb-25">92.6k</h2>
                        <p class="mb-0">New Registered User Gained</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <div class="card">
                    <div class="card-header d-flex flex-column align-items-start pb-0">
                        <div class="avatar bg-rgba-warning p-50 m-0">
                            <div class="avatar-content">
                                <i class="feather icon-package text-warning font-medium-5"></i>
                            </div>
                        </div>
                        <h2 class="text-bold-700 mt-1 mb-25">97.5K</h2>
                        <p class="mb-0">Money Received</p>
                    </div>
                </div>
            </div>
        </div>
<!-- -----User Gained Chart------ -->
        <?php echo $__env->make('admin.include.charts.user-gained', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">New Regsitered Users</h4>
                    </div>
                    <div class="card-content">
                        <div class="table-responsive mt-1">
                            <table class="table table-hover-animation mb-0">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Registeration Type</th>
                                        <th>Added On</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->name); ?><br>
                                        <sub>Username: <?php echo e($user->username); ?></sub>
                                        </td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->phone); ?></td>
                                        <td>
                                          <?php echo e($user->registeration_type); ?>

                                        </td>
                                        <td><?php echo e(date('dS F,Y',strtotime($user->created_at))); ?> at <?php echo e(date('g:ia',strtotime($user->created_at))); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> 

<?php $__env->stopSection(); ?>
<?php $__env->startPush('vendor-script'); ?>
        <!-- vendor files -->
        <script src="<?php echo e(asset('app-assets/vendors/js/charts/apexcharts.min.js')); ?>"></script>
        <script src="<?php echo e(asset('app-assets/vendors/js/extensions/tether.min.js')); ?>"></script>
        <script src="<?php echo e(asset('app-assets/vendors/js/extensions/shepherd.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('page-script'); ?>
        <!-- Page js files -->
        <script src="<?php echo e(asset('app-assets/js/scripts/pages/dashboard-analytics.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ccloser-admin\resources\views/admin/welcome.blade.php ENDPATH**/ ?>