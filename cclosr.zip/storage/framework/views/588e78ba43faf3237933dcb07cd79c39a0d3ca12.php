<!--header section start-->
<header class="header">
    <!--start navbar-->
    <nav class="navbar navbar-expand-lg fixed-top gradient-bg">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('frontend/img/logo-white.png')); ?>" width="170" alt="logo" class="img-fluid"/>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="ti-menu"></span>
            </button>
            <div class="collapse navbar-collapse h-auto" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto menu">
                    <li><a href="<?php echo e(url('/')); ?>" class="page-scroll">Home</a></li>
                    
                     <?php
                      $aboutUs = DB::table('static_pages')->where('status','1')->where('type','about-us')->get();
                    ?> 
                     <?php $__currentLoopData = $aboutUs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <li><a href="<?php echo e(route('get.static.page',['slug'=>$items->type])); ?>" class="page-scroll"><?php echo e($items->title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
                    <li><a href="<?php echo e(route('get.membership.index')); ?>" class="page-scroll">Membership plan</a></li>

                    <li><a href="<?php echo e(route('get.contact.index')); ?>" class="page-scroll">Contact Us</a></li>
                      <?php if(Auth::check()): ?>
                       <?php
                          $credit=DB::table('membership_credits')->where('user_id', Auth::user()->id)->orderBy('id', 'desc')->first();
                        ?>
                             <li><a href="#" class="page-scroll badge badge-pill bg-template"><b>Point :</b> <?php echo e($credit->available_credit); ?></a></li>
                     
                      <li class="dropdown pr-4" style="vertical-align: middle;">
                        <a href="#" >
                         <img src="<?php echo e(asset('images/avatar/avatar.png')); ?>" class="dropdown-toggle  rounded-circle shadow-sm" width="40" height="40" alt="Profile"/>
                        </a>
                        <ul class="sub-menu">
                            <li><a href="#"><?php echo e(Auth::user()->name); ?></a></li>
                            <li><a href="<?php echo e(route('user.get.logout')); ?>">Logout</a></li>
                        </ul>
                    </li>
                    <?php else: ?>
                    <li><a href="<?php echo e(route('user.get.login')); ?>" class="page-scroll">Login</a></li>
                     <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</header>
<!--header section end--><?php /**PATH C:\xampp\htdocs\ccloser-admin\resources\views/frontend/include/header-2.blade.php ENDPATH**/ ?>