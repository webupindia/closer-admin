
<?php $__env->startSection('title', 'Forget Password '); ?>
<?php $__env->startSection('content'); ?>
<!--hero section start-->
    <section class="hero-section full-screen gray-light-bg " >
        <div class="container-fluid">
            <div class="row align-items-center justify-content-center">

                <div class="col-12 col-md-7 col-lg-6 col-xl-8 d-none d-lg-block">

                    <!-- Image -->
                    <div class="bg-cover vh-100 ml-n3 gradient-overlay-trns"  style="background: url(<?php echo e(asset('frontend/img/hero-bg-4.jpg')); ?>) no-repeat center center / cover">
                        <div class="position-absolute login-signup-content">
                            <div class="position-relative text-white col-md-12 col-lg-7">
                                <h2 class="text-white">Forgot Password ? <br> Don't Worry You Can Reset</h2>
                                <p class="lead">Keep your face always toward the sunshine - and shadows will fall behind you. Continually pursue fully researched niches whereas timely platforms. Credibly parallel task optimal catalysts for change after focused catalysts for change.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-5 col-lg-6 col-xl-4 px-lg-6">
                    <div class="login-signup-wrap px-4 px-lg-5 my-5">
                        <!-- Heading -->
                        <h1 class="text-center mb-1">
                           Forget Password
                        </h1>

                        <!-- Subheading -->
                        <p class="text-muted text-center mb-5">
                            Please enter your registered email address. An email notification
                            with a password reset link will then be sent to you. 
                        </p>

                        <!-- Form -->
                        <form class="login-signup-form" action="<?php echo e(route('user.post.forget-password')); ?>" method="post">
                           <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <div class="input-group input-group-merge">
                                    <div class="input-icon">
                                        <span class="ti-email color-primary"></span>
                                    </div>
                                    <input type="email" name="email" class="form-control" placeholder="Enter Your Email">
                                </div>
                                  <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            </div>
                            <!-- Submit -->
                            <button type="submit" class="btn btn-block solid-btn border-radius mt-4 mb-3">
                                Reset Password
                            </button>

                            <!-- Link -->
                            <div class="text-center">
                                <small class="text-muted text-center">
                                    Remember your password? <a href="<?php echo e(route('user.get.login')); ?>">Log in</a>.
                                </small>
                            </div>

                        </form>
                    </div>
                </div>
            </div> <!-- / .row -->
        </div>
    </section>
    <!--hero section end-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.custom-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ccloser-admin\resources\views/frontend/auth/forget-password.blade.php ENDPATH**/ ?>