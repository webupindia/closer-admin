
<?php $__env->startSection('title',__('Login | Ccloser Admin')); ?>
<?php $__env->startSection('page-style'); ?>
        
        <link rel="stylesheet" href="<?php echo e(asset('css/pages/authentication.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
  <script src="<?php echo e(asset('js/scripts/auth/login.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="row flexbox-container">
  <div class="col-xl-8 col-11 d-flex justify-content-center">
      <div class="card bg-authentication rounded-0 mb-0">
          <div class="row m-0">
              <div class="col-lg-6 d-lg-block d-none text-center align-self-center px-1 py-0">
                  <img src="<?php echo e(asset('app-assets/images/pages/login.png')); ?>" alt="branding logo">
              </div>
              <div class="col-lg-6 col-12 pb-2">
                  <div class="card rounded-0 mb-0 px-2">
                      <div class="card-header pb-1">
                          <div class="card-title">
                              <h4 class="mb-0">Login</h4>
                          </div>
                      </div>
             
                        <p class="px-2">Welcome back, please login to your account.</p>
                 
                      <div class="card-content">
                          <div class="card-body pt-1">
                            <form method="POST" action="<?php echo e(route('admin.post.login')); ?>">
                              <?php echo csrf_field(); ?>
                              <fieldset class="form-label-group form-group position-relative has-icon-left">

                                  <input id="email" type="email" class="form-control" name="email" placeholder="E-Mail Address" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                     <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                  <div class="form-control-position">
                                      <i class="feather icon-user"></i>
                                  </div>
                                  <label for="email">E-Mail Address</label>
                              </fieldset>

                              <fieldset class="form-label-group position-relative has-icon-left">

                                  <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>
                                 <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                  <div class="form-control-position">
                                      <i class="feather icon-lock"></i>
                                  </div>
                                  <label for="password">Password</label>
                              </fieldset>
                              <button type="submit" class="btn btn-primary float-left btn-inline">Login</button>
                            </form>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.fullLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ccloser-admin\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>