<script src="<?php echo e(asset('frontend/js/jquery-3.4.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/jquery.countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/validator.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/scripts.js')); ?>"></script>
 <?php echo $__env->yieldPushContent('page-script'); ?> <!-- Page JS--><?php /**PATH C:\xampp\htdocs\ccloser-admin\resources\views/frontend/include/script.blade.php ENDPATH**/ ?>