
<?php $__env->startSection('title'); ?>
<?php echo e($SpecificData->title); ?> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <!--hero section start-->
    <section class="hero-section ptb-100 gradient-overlay-trns"
             style="background: url(<?php echo e(asset('frontend/img/hero-bg-4.jpg')); ?>)no-repeat center center / cover">
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-md-9 col-lg-7">
                    <div class="page-header-content text-white text-center pt-sm-5 pt-md-5 pt-lg-0">
                        <h1 class="text-white mb-0"><?php echo e($SpecificData->title); ?></h1>
                        <div class="custom-breadcrumb">
                            <ol class="breadcrumb d-inline-block bg-transparent list-inline py-0">
                                <li class="list-inline-item breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                <li class="list-inline-item breadcrumb-item active"><?php echo e($SpecificData->title); ?></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--hero section end-->
        <!--Privacy-policy secion start-->
    <section class="promo-new-section ptb-100">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12">
                
                       <?php echo $SpecificData->content; ?>

              
                </div>
            </div>
        </div>
    </section>
    <!--Privacy-policy secion end-->
     

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ccloser-admin\resources\views/frontend/static-pages/index.blade.php ENDPATH**/ ?>