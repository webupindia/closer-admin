 <!--contact us section start-->
    <section id="contact" class="contact-us-section contact-us ptb-100">
        <div class="container">
            <div class="row justify-content-around">
                <div class="col-md-6">
                    <div class="message-box d-none">
                        <div class="alert alert-danger"></div>
                    </div>
                    <div class="contact-us-form gray-light-bg rounded p-5">
                        <h4 class="pb-4">Contact Us</h4>
                        <form action="<?php echo e(route('post.contact.sendMailContact')); ?>" method="post"  class="contact-us-form" >
                        <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-6 col-12">
                                    <div class="form-group">
                                        <input type="text" class="form-control" value="<?php echo e(old('name')); ?>" name="name" id="name" placeholder="Enter name"
                                               required="required">
                                    </div>
                                     <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                </div>
                                <div class="col-sm-6 col-12">
                                    <div class="form-group">
                                        <input type="email" class="form-control" value="<?php echo e(old('email')); ?>" name="email" id="email" placeholder="Enter email"
                                               required="required">
                                    </div>
                                      <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6 col-12">
                                    <div class="form-group">
                                        <input type="text" value="<?php echo e(old('phone')); ?>" name="phone"  class="form-control" id="phone"
                                               placeholder="Your Phone">
                                    </div>
                                     <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                                </div>
                                <div class="col-sm-6 col-12">
                                    <div class="form-group">
                                        <input type="text" value="<?php echo e(old('company')); ?>" name="company"  size="40" class="form-control"
                                               id="company" placeholder="Your Company">
                                    </div>
                                     <span class="text-danger"><?php echo e($errors->first('company')); ?></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                    <textarea name="message" value="<?php echo e(old('message')); ?>" id="message" class="form-control" rows="7" cols="25"
                                              placeholder="Message"></textarea>
                                    </div>
                                     <span class="text-danger"><?php echo e($errors->first('message')); ?></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 mt-3">
                                    <button type="submit" class="btn solid-btn" id="btnContactUs">
                                        Send Message
                                    </button>
                                </div>
                            </div>
                        </form>
                        <p class="form-message"></p>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="contact-us-content">
                        <h2>Have questions about CCLOSER?</h2>
                        <p class="lead">Please reach out — we’re happy to help.</p>

                        <a href="#" class="btn outline-btn align-items-center">Get Directions <span class="ti-arrow-right pl-2"></span></a>

                        <hr class="my-5">

                        <h5>Our Headquarters</h5>
                        <address>
                           Satyawati colony Ashok Vihar Delhi-110052
                        </address>
                        <br>
                        <span>Phone: +1234567890123</span> <br>
                        <span>Email: <a href="mailto:teamccloser@gmail.com" class="link-color">teamccloser@gmail.com</a></span>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--contact us section end--><?php /**PATH C:\xampp\htdocs\ccloser-admin\resources\views/frontend/include/contact-form.blade.php ENDPATH**/ ?>