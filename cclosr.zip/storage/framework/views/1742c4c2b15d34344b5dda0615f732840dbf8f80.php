
<?php $__env->startSection('title', 'Failure '); ?>
<?php $__env->startSection('content'); ?>
 <!--hero section start-->
    <section class="hero-section ptb-100 ">
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-md-9 col-lg-7">
                    <div class="error-content text-center text-dark pt-4">
                        <img src="<?php echo e(asset('frontend/img/failed.png')); ?>" width="120px;" class="pt-4 m-auto d-block" />
                        <h3 class="text-dark pt-2"> Your Transaction Failed! </h3>
                        <p> Your payment was not successful Processed.
                            Please contact our customer support.
                        </p><a class="btn outline-btn align-items-center" href="<?php echo e(url('/')); ?>">Go to Homepage</a></div>
                </div>
            </div>
        </div>
    </section>
    <!--hero section end-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.custom-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ccloser-admin\resources\views/frontend/payment/failure.blade.php ENDPATH**/ ?>