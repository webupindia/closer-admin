      
    <div class="row">
    <div class="col-xl-12">
        <div class="card m-b-20">
            <div class="card-body">
                <h4 class="mt-0 header-title">Users Gained</h4>
                <div id="pop_div"></div>
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/modules/series-label.js"></script>
  <script src="https://code.highcharts.com/modules/exporting.js"></script>
  <script src="https://code.highcharts.com/modules/export-data.js"></script>
  <script>
  Highcharts.chart('pop_div', {
  title: {
  text: 'User Registeration Month Wise'
  },
  yAxis: {
  title: {
  text: 'Number of Users'
  }
  },
  legend: {
  layout: 'vertical',
  align: 'right',
  verticalAlign: 'middle'
  },
  xAxis: {
   categories: [
  <?php
  foreach($data as $report)
  echo "'{$report->year}-{$report->month}-01',\r\n";
  ?>
  ],
  crosshair: true
  },
  series: [
  {
  name: 'User Registered',
  data: [
  <?php
  foreach($data as $item)
  echo "{$item->user},\r\n";
  ?>
  ]
  }],
  responsive: {
  rules: [{
  condition: {
  maxWidth: 500
  },
  chartOptions: {
  legend: {
  layout: 'horizontal',
  align: 'center',
  verticalAlign: 'bottom'
  }
  }
  }]
  }
  });
  </script>
    </div>
  </div>
  </div>
  </div>
<?php /**PATH C:\xampp\htdocs\ccloser-admin\resources\views/admin/include/charts/user-gained.blade.php ENDPATH**/ ?>