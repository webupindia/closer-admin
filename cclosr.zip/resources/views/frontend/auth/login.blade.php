@extends('frontend.layouts.app')
@section('title', 'Login ')
@section('content')
<!--hero section start-->
    <section class="hero-section ptb-100 gradient-overlay-trns full-screen"
             style="background: url({{asset('frontend/img/hero-bg-4.jpg')}}) no-repeat center center / cover">
        <div class="container">
            <div class="row align-items-center justify-content-between pt-5 pt-sm-5 pt-md-5 pt-lg-0">
                <div class="col-md-7 col-lg-6">
                    <div class="hero-content-left text-white">
                        <h1 class="text-white">Welcome Back !</h1>
                        <p class="lead">
                            Keep your face always toward the sunshine - and shadows will fall behind you.
                        </p>
                    </div>
                </div>
                <div class="col-md-5 col-lg-5">
                    <div class="card login-signup-card shadow-lg mb-0">
                        <div class="card-body px-md-5 py-5">
                            <div class="mb-3">
                                <h5 class="h3">Login</h5>
                                <p class="text-muted mb-0">Sign in to your account to continue.</p>
                            </div>
                            <div class="row mb-2">
                            <div class="col-md-6">  <a href="{{route('login.google')}}" class="btn btn-block btn-danger border-radius">
                            <span class="ti-google"></span> Google
</a></div>
                            <div class="col-md-6">  <a href="{{route('login.facebook')}}" class="btn btn-block btn-primary  border-radius ">
                            <span class="ti-facebook"></span>   Facebook
</a> </div>
                            </div>
                            <!--login form-->
                            <form class="login-signup-form" action="{{route('user.post.login')}}" method="post" >
                             @csrf
                                <div class="form-group">
                                    <label class="pb-1">Email Address</label>
                                    <div class="input-group input-group-merge">
                                        <div class="input-icon">
                                            <span class="ti-email color-primary"></span>
                                        </div>
                                        <input type="email" name="email" value="{{ old('email') }}" class="form-control" placeholder="Enter your Email ">
                                    </div>
                                     <span class="text-danger">{{ $errors->first('email') }}</span>
                                </div>
                                <!-- Password -->
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col">
                                            <label class="pb-1">Password</label>
                                        </div>
                                        <div class="col-auto">
                                            <a href="{{route('user.get.forget-password')}}" class="form-text small text-muted">
                                                Forgot password?
                                            </a>
                                        </div>
                                    </div>
                                    <div class="input-group input-group-merge">
                                        <div class="input-icon">
                                            <span class="ti-lock color-primary"></span>
                                        </div>
                                        <input type="password" name="password" class="form-control" placeholder="Enter your password">
                                    </div>
                                    <span class="text-danger">{{ $errors->first('password') }}</span>
                                </div>

                                <!-- Submit -->
                                <button type="submit" class="btn btn-block solid-btn border-radius mt-4 mb-3">
                                    Sign in
                                </button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="shape-bottom">
            <img src="{{asset('frontend/img/hero-shape-bottom.svg')}}" alt="shape" class="bottom-shape img-fluid">
        </div>
    </section>
    <!--hero section end-->




@endsection