@extends('frontend.layouts.app')
@section('title', 'Checkout ')
@section('content')
<!--hero section start-->
<section class="hero-section ptb-100 gradient-overlay-trns"
    style="background: url({{ asset('frontend/img/hero-bg-4.jpg') }})no-repeat center center / cover">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-md-9 col-lg-7">
                <div class="page-header-content text-white text-center pt-sm-5 pt-md-5 pt-lg-0">
                    <h1 class="text-white mb-0">Checkout</h1>
                    <div class="custom-breadcrumb">
                        <ol class="breadcrumb d-inline-block bg-transparent list-inline py-0">
                            <li class="list-inline-item breadcrumb-item"><a
                                    href="{{ url('/') }}">Home</a></li>
                            <li class="list-inline-item breadcrumb-item active">Checkout</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--hero section end-->
<!--pricing section start-->
<section class=" ptb-100 ">
    <div class="container">
      <form action="{{route('Initiate')}}" method="post">
        @csrf
        <div class="row ">
            <div class="col-lg-8 col-md-8 col-12 ">
                <div class="card text-center ">
                    <table class="table ">
                        <thead>
                            <tr>
                                <th><b>Plan Name</b></th>
                                <th><b>Plan Credits</b></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Membership Plan 3</td>
                                  <input type="hidden" name="credit" value=" {{$getResult->credit}}">
                                <td><b>{{$getResult->credit}}</b> Credits</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12 ">
                <div class="accordion accordion-faq ">
                    <!-- Accordion card 3 -->
                    <div class="card">
                        <div class="card-header py-3">
                               <h4 class="mb-0">Order Summary 
                            </h4>
                        </div>
                       
                    </div>
                    <div class="card">
                        <div class="card-header py-3">
                            <div class="p-1">
                            <input type="hidden" name="amount" value=" {{$getResult->amount}}">
                                <h5>Plan Amount <span class="float-right">₹ {{$getResult->amount}}</span></h5>
                            </div>
                              <button type="submit" class="btn solid-btn btn-block btn-not-rounded mt-3">Pay Now
                                </button>
                               
                        </div>
                    
                    </div>
                </div>

            </div>
        </div>
        </form>
    </div>

</section>

@endsection
