<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Ccloser">
     <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title') | {{ config('app.name') }}</title>
    <!--favicon icon-->
     <link rel="shortcut icon" type="image/x-icon" href="{{ asset('images/logo/favicon.ico') }}">
    {{-- Include core Styles --}}
    @include('frontend.include.style')
    @notifyCss
</head>
<body>
<!--loader start-->
<div id="preloader">
    <div class="loader1">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
    </div>
</div>
<!--loader end-->
<!--body content wrap start-->
<div class="main">
    
    @include('frontend.include.header-2') <!--header-2 section-->
    @yield('content')                     <!--body content-->
    <x:notify-messages />
    @include('frontend.include.footer')   <!--footer section-->
</div>    
<!--bottom to top button start-->
<button class="scroll-top scroll-to-target" data-target="html">
    <span class="ti-angle-up"></span>
</button>

<!--bottom to top button end-->
{{-- Include core Script --}}
 @include('frontend.include.script')
 @notifyJs
</body>
</html>
