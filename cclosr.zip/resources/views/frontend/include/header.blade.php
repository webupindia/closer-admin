<!--header section start-->
<header class="header">
    <!--start navbar-->
    <nav class="navbar navbar-expand-lg fixed-top bg-transparent">
        <div class="container">
            <a class="navbar-brand" href="{{url('/')}}">
                <img src="{{asset('frontend/img/logo-white.png')}}" width="170" alt="logo" class="img-fluid"/>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="ti-menu"></span>
            </button>
            <div class="collapse navbar-collapse h-auto" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto menu">
                    <li><a href="{{url('/')}}" class="page-scroll">Home</a></li>
                    {{-- About us --}}
                     <?php
                      $aboutUs = DB::table('static_pages')->where('status','1')->where('type','about-us')->get();
                    ?> 
                     @foreach($aboutUs as $items)
                     <li><a href="{{route('get.static.page',['slug'=>$items->type])}}" class="page-scroll">{{ $items->title }}</a></li>
                    @endforeach
                     {{--End About us --}}
                    <li><a href="{{route('get.membership.index')}}" class="page-scroll">Membership plan</a></li>
                    <li><a href="{{route('get.contact.index')}}" class="page-scroll">Contact Us</a></li>
                     @if (Auth::check())
                      <?php
                          $credit=DB::table('membership_credits')->where('user_id', Auth::user()->id)->orderBy('id', 'desc')->first();
                        ?>
                             <li><a href="#" class="page-scroll badge badge-pill bg-template"><b>Point :</b> {{$credit->available_credit}}</a></li>
                     
                      <li class="dropdown pr-4" style="vertical-align: middle;">
                        <a href="#" >
                         <img src="{{asset('images/avatar/avatar.png')}}" class="dropdown-toggle  rounded-circle shadow-sm" width="40" height="40" alt="Profile"/>
                        </a>
                        <ul class="sub-menu">
                            <li><a href="#">{{Auth::user()->name}}</a></li>
                            <li><a href="{{route('user.get.logout')}}">Logout</a></li>
                        </ul>
                    </li>
                    @else
                    <li><a href="{{route('user.get.login')}}" class="page-scroll">Login</a></li>
                     @endif
                </ul>
            </div>
        </div>
    </nav>
</header>
<!--header section end-->