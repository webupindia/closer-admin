@extends('frontend.layouts.app')
@section('title', 'Home ')
@section('content')
<!--hero section start-->
    <section class="hero-equal-height ptb-100 gradient-overlay"
             style="background: url({{asset('frontend/img/galaxy-image.jpg')}})no-repeat center center / cover">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 col-lg-6">
                    <div class="hero-content-left text-white my-lg-0 my-md-5 my-sm-5 my-5">
                        <h1 class="text-white">How to Deliver Ddigital Experiences</h1>
                        <p class="lead">
                            Our design projects are fresh and simple and will benefit your business greatly. Learn more
                            about our work!
                        </p>
                        <div class="action-btns download-btn mt-4">
                            <a href="#" class="btn solid-white-btn animated-btn mr-lg-3">Download Now</a>
                            <a href="#" class="btn outline-white-btn animated-btn">Contact with us</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-5 col-lg-6">
                    <div class="video-app-wrap ml-auto mt--120 d-none d-sm-none d-md-block d-lg-block">
                        <div class="iphone-mask">
                            <img src="{{asset('frontend/img/hero-app-image.png')}}" alt="app" class="img-fluid mask-img"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="shape-bottom overflow-hidden">
            <img src="{{asset('frontend/img/hero-shape.svg')}}" alt="shape" class="bottom-shape">
        </div>
    </section>
    <!--hero section end-->


    <!--promo neb secion start-->
    <section class="promo-new-section ptb-100">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-lg-8">
                    <div class="section-heading mb-5">
                        <h2>Why You Need AppBeats</h2>
                        <p>We will helps you to build beautiful websites that stand out and automatically adapt to your style. Assertively envisioneer standardized portals with high standards in results.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-lg-4">
                    <div class="single-promo single-promo-hover single-promo-1 rounded text-center white-bg p-5 h-100">
                        <div class="circle-icon mb-5">
                            <span class="ti-vector text-white"></span>
                        </div>
                        <h5>Clean Design</h5>
                        <p>Increase sales by showing true dynamics of your website.</p>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4">
                    <div class="single-promo single-promo-hover single-promo-1 rounded text-center white-bg p-5 h-100">
                        <div class="circle-icon mb-5">
                            <span class="ti-lock text-white"></span>
                        </div>
                        <h5>Secure Data</h5>
                        <p>Build your online store’s trust using Social Proof &amp; Urgency.</p>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4">
                    <div class="single-promo single-promo-hover single-promo-1 rounded text-center white-bg p-5 h-100">
                        <div class="circle-icon mb-5">
                            <span class="ti-eye text-white"></span>
                        </div>
                        <h5>Retina Ready</h5>
                        <p>Realize importance of social proof in customer’s purchase decision.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--promo neb secion end-->

    <!--features section start-->
    <div id="features" class="feature-section gray-light-bg ptb-100">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-9 col-lg-9">
                    <div class="section-heading text-center mb-5">
                        <h2>Quick & Easy Process With Best Features</h2>
                        <p>Objectively deliver professional value with diverse web-readiness.
                            Collaboratively transition wireless customer service without goal-oriented catalysts for
                            change. Collaboratively.</p>

                    </div>
                </div>
            </div>

            <!--feature new style start-->
            <div class="row align-items-center">
                <div class="col-lg-4 col-md-12">
                    <div class="row">
                        <div class="col-12">
                            <div class="d-flex align-items-start mb-sm-0 mb-md-5 mb-lg-5">
                                <span class="ti-face-smile icon-sm color-1 color-1-bg p-3 mr-4 mt-1 rounded"></span>
                                <div class="icon-text">
                                    <h5 class="mb-2">Responsive web design</h5>
                                    <p>Modular and interchangable componente between layouts and even demos.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="d-flex align-items-start mb-sm-0 mb-md-5 mb-lg-5">
                                <span class="ti-vector icon-sm color-2 color-2-bg p-3 mr-4 mt-1 rounded"></span>
                                <div class="icon-text">
                                    <h5 class="mb-2">Loaded with features</h5>
                                    <p>Modular and interchangable componente between layouts and even demos.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="d-flex align-items-start mb-sm-0 mb-md-5 mb-lg-5">
                                <span class="ti-headphone-alt icon-sm color-5 color-5-bg p-3 mr-4 mt-1 rounded"></span>
                                <div class="icon-text">
                                    <h5 class="mb-2">Friendly online support</h5>
                                    <p>Modular and interchangable componente between layouts and even demos.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12 d-none d-sm-none d-md-block d-lg-block">
                    <div class="position-relative pb-md-5 py-lg-0">
                        <img alt="Image placeholder" src="{{asset('frontend/img//image-10.png')}}" class="img-center img-fluid">
                    </div>
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="row">
                        <div class="col-12">
                            <div class="d-flex align-items-start mb-sm-0 mb-md-5 mb-lg-5">
                                <span class="ti-layout-media-right icon-sm color-4 color-4-bg p-3 mr-4 mt-1 rounded"></span>
                                <div class="icon-text">
                                    <h5 class="mb-2">Free updates forever</h5>
                                    <p>Modular and interchangable componente between layouts and even demos.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="d-flex align-items-start mb-sm-0 mb-md-5 mb-lg-5">
                                <span class="ti-layout-cta-right icon-sm color-3 color-3-bg p-3 mr-4 mt-1 rounded"></span>
                                <div class="icon-text">
                                    <h5 class="mb-2">Built with Sass</h5>
                                    <p>Modular and interchangable componente between layouts and even demos.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="d-flex align-items-start mb-sm-0 mb-md-5 mb-lg-5">
                                <span class="ti-palette icon-sm color-6 color-6-bg p-3 mr-4 mt-1 rounded"></span>
                                <div class="icon-text">
                                    <h5 class="mb-2">Infinite colors</h5>
                                    <p>Modular and interchangable componente between layouts and even demos.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--feature new style end-->
        </div>
    </div>
    <!--features section end-->

    <!--screenshots section start-->
    <section id="screenshots" class="screenshots-section ptb-100 gray-light-bg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-9 col-lg-8">
                    <div class="section-heading text-center mb-5">
                        <h2>Show Our Apps Screenshots</h2>
                        <p>Credibly synthesize multimedia based networks vis-a-vis top-line growth strategies. Continually leverage existing worldwide interfaces </p>
                    </div>
                </div>
            </div>
            <!--start app screen carousel-->
            <div class="screen-slider-content">
                <div class="screenshot-frame"></div>
                <div class="screen-carousel owl-carousel owl-theme dot-indicator">
                    <img src="{{asset('frontend/img/screenshoot-1.png')}}" class="img-fluid" alt="screenshots"/>
                    <img src="{{asset('frontend/img/screenshoot-2.jpg')}}" class="img-fluid" alt="screenshots"/>
                    <img src="{{asset('frontend/img/screenshoot-3.jpg')}}" class="img-fluid" alt="screenshots"/>
                    <img src="{{asset('frontend/img/screenshoot-1.png')}}" class="img-fluid" alt="screenshots"/>
                    <img src="{{asset('frontend/img/screenshoot-2.jpg')}}" class="img-fluid" alt="screenshots"/>
                    <img src="{{asset('frontend/img/screenshoot-3.jpg')}}" class="img-fluid" alt="screenshots"/>
                </div>
            </div>
            <!--end app screen carousel-->

        </div>
    </section>
    <!--screenshots section end-->

    <!--download section start-->
    <section id="download" class="gradient-overlay"
             style="background: url({{asset('img/hero-bg-3.jpg')}})no-repeat center center / cover">
        <div class="container">
            <div class="row justify-content-around align-items-end">
                <div class="col-md-6 col-lg-5">
                    <div class="download-txt text-white ptb-100">
                        <h2 class="text-white pb-3" >
                            What we do
                        </h2>
                        <p class="lead">"Pictures are the best memories"</p>
                        <p>There are lot of moments when you wish to capture that perfect shot when your bae is not around, it is at that time when Ccloser turns out to be the most handy tool. Wondering how.
                         Well simply open our app and send a Ccloser request to the one with whom you wish to capture a photograph, 
                         our AI based algorithms work in such a manner to create a unified image of both the individuals</p>
                
                    </div>
                </div>
                <div class="col-md-6 col-lg-7">
                    <div class="d-flex align-items-end">
                        <img class="img-fluid" src="{{asset('frontend/img/we-do.webp')}}" alt="download"/>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--download section end-->


    {{-- Contact Form  --}}
      @include('frontend.include.contact-form')
    <!--contact us section end-->
@endsection