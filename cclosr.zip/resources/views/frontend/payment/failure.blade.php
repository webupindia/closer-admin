@extends('frontend.layouts.custom-header')
@section('title', 'Failure ')
@section('content')
 <!--hero section start-->
    <section class="hero-section ptb-100 ">
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-md-9 col-lg-7">
                    <div class="error-content text-center text-dark pt-4">
                        <img src="{{asset('frontend/img/failed.png')}}" width="120px;" class="pt-4 m-auto d-block" />
                        <h3 class="text-dark pt-2"> Your Transaction Failed! </h3>
                        <p> Your payment was not successful Processed.
                            Please contact our customer support.
                        </p><a class="btn outline-btn align-items-center" href="{{url('/')}}">Go to Homepage</a></div>
                </div>
            </div>
        </div>
    </section>
    <!--hero section end-->
@endsection