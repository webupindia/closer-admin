@extends('frontend.layouts.app')
@section('title', 'About Us ')
@section('content')
 <!--hero section start-->
    <section class="hero-section ptb-100 gradient-overlay-trns"
             style="background: url({{asset('frontend/img/hero-bg-4.jpg')}})no-repeat center center / cover">
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-md-9 col-lg-7">
                    <div class="page-header-content text-white text-center pt-sm-5 pt-md-5 pt-lg-0">
                        <h1 class="text-white mb-0">About Us</h1>
                        <div class="custom-breadcrumb">
                            <ol class="breadcrumb d-inline-block bg-transparent list-inline py-0">
                                <li class="list-inline-item breadcrumb-item"><a href="{{url('/')}}">Home</a></li>
                                <li class="list-inline-item breadcrumb-item active">About Us</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--hero section end-->
     <!--About Us secion start-->
    <section class="promo-new-section ptb-100">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12">
                   @foreach($aboutUs as $item)
                       {!! $item->content !!}
                   @endforeach
                </div>
            </div>
        </div>
    </section>
    <!--About Us secion end-->
     



@endsection