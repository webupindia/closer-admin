@extends('admin.layouts.app')
@section('title',__('Profile | Ccloser Admin'))
@section('content')
<nav aria-label="breadcrumb">
     <h2 class="content-header-title float-left mb-0">Admin Profile</h2>
     <ol class="breadcrumb breadcrumb-pipes">
        <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Profile</li>
    </ol>
</nav>
<!-- account setting page start -->
<section id="page-account-settings">
    <div class="row">
        <!-- left menu section -->
        <div class="col-md-3 mb-2 mb-md-0">
            <ul class="nav nav-pills flex-column mt-md-0 mt-1">
                <li class="nav-item">
                    <a class="nav-link d-flex py-75 active" id="account-pill-general" data-toggle="pill"
                        href="#account-vertical-general" aria-expanded="true">
                        <i class="feather icon-user mr-50 font-medium-3"></i>
                        Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link d-flex py-75" id="account-pill-password" data-toggle="pill"
                        href="#account-vertical-password" aria-expanded="false">
                        <i class="feather icon-lock mr-50 font-medium-3"></i>
                        Change Password
                    </a>
                </li>
            </ul>
        </div>
        <!-- right content section -->
        <div class="col-md-9">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="account-vertical-general"
                                aria-labelledby="account-pill-general" aria-expanded="true">
                                <form action="{{route('profile.post.update')}}" method="post">
                                    @csrf
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <div class="controls">
                                                    <label for="account-name">Name</label>
                                                    <input type="text" name="name" class="form-control" id="account-name"
                                                        placeholder="Name" value="{{Auth::guard('admin')->user()->name}}" required >
                                                     <span class="text-danger">{{ $errors->first('name') }}</span>     
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <div class="controls">
                                                    <label for="account-e-mail">E-mail</label>
                                                    <input type="email" name="email" class="form-control" id="account-e-mail"
                                                    placeholder="Email" value="{{Auth::guard('admin')->user()->email}}" required
                                                       >
                                                 <span class="text-danger">{{ $errors->first('email') }}</span>   
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-12 d-flex flex-sm-row flex-column justify-content-end">
                                            <button type="submit"
                                                class="btn btn-primary mr-sm-1 mb-1 mb-sm-0">Update</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="tab-pane fade " id="account-vertical-password" role="tabpanel"
                                aria-labelledby="account-pill-password" aria-expanded="false">
                                <form action="{{route('password.post.update')}}" method="post">
                                    @csrf
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <div class="controls">
                                                    <label for="account-old-password">Old Password</label>
                                                    <input type="password" name="old_password" class="form-control"
                                                        id="account-old-password" placeholder="Old Password" >
                                                    <span class="text-danger">{{ $errors->first('old_password') }}</span>   
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <div class="controls">
                                                    <label for="account-new-password">New Password</label>
                                                    <input type="password" name="password" id="account-new-password" class="form-control" placeholder="New Password" >
                                                    <span class="text-danger">{{ $errors->first('password') }}</span>      
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <div class="controls">
                                                    <label >Retype New Password</label>
                                                    <input type="password" name="password_confirmation" class="form-control"
                                                         placeholder="New Password">
                                                      <span class="text-danger">{{ $errors->first('password_confirmation') }}</span>      
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 d-flex flex-sm-row flex-column justify-content-end">
                                            <button type="submit"
                                                class="btn btn-primary mr-sm-1 mb-1 mb-sm-0">Update</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- account setting page end -->
@endsection