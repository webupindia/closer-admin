@extends('admin.layouts.app')
@section('title', 'All Template ')

@push('vendor-style')
        {{-- vendor files --}}
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/charts/apexcharts.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/datatables.min.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/file-uploaders/dropzone.min.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/extensions/dataTables.checkboxes.css') }}">
@endpush
@push('page-style')
        {{-- Page css files --}}
        <link rel="stylesheet" href="{{ asset('app-assets/css/plugins/file-uploaders/dropzone.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/css/pages/data-list-view.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/core/menu/menu-types/vertical-menu.css') }}">
        <!--Start  Session Error Show Side Panel -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

        @if(Session::has('errors'))
        <script>
            $(document).ready(function() {
                $('.add-new-data').addClass('show');
                $('.overlay-bg').addClass('show');
            });
        </script>
        @endif
        <!--End  Session Error Show Side Panel -->         
@endpush
@section('content')
<nav aria-label="breadcrumb">
     <h2 class="content-header-title float-left mb-0">Theme Template</h2>
     <ol class="breadcrumb breadcrumb-pipes">
        <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Theme Template</li>
    </ol>
</nav>
{{-- Data list view starts --}}
  <!-- Data list view starts -->
                <section id="data-list-view" class="data-list-view-header">
                    <div class="action-btns d-none">
                        <div class="btn-dropdown mr-1 mb-1">
                            <div class="btn-group dropdown actions-dropodown">
                               
                            </div>
                        </div>
                    </div>

                    <!-- DataTable starts -->
                    <div class="table-responsive">
                        <table class="table data-list-view">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>TEMPLATE PICTURE</th>
                                    <th>TEMPLATE NAME</th>
                                    <th>STATUS</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
                                  @foreach($templates as $template)
                                <tr id="deleteRow">
                                    <td><b>{{ $loop->iteration }}</b></td>
                                    <td><a target="blank" href="{{asset('storage/template/'.$template->url)}}"><img src="{{asset('storage/template/'.$template->url)}}" width="100px" height="auto"></a></td>
                                    <td>{{ $template->name}}</td>
                                    <td>
                                        @if($template->status==1)
                                        <a href="{{ route('template.get.inactive',['id'=>Crypt::encrypt($template->id)]) }}">
                                            <div class="chip chip-success">
                                                <div class="chip-body">
                                                <div class="chip-text">
                                                        Active
                                                </div>
                                                </div>
                                            </div>
                                          </a>
                                        @else
                                            <a href="{{ route('template.get.active',['id'=>Crypt::encrypt($template->id)]) }}">
                                            <div class="chip chip-error">
                                                <div class="chip-body">
                                                <div class="chip-text">
                                                        Inactive
                                                </div>
                                                </div>
                                            </div>
                                            </a>
                                        @endif
                                    </td>
                                    <td class="product-action">
                                        <span class="action"><a href="{{route('template.get.delete',['id'=>Crypt::encrypt($template->id)])}}" onclick="return confirm('Are you sure you want to delete this template?')"><i class="feather icon-trash"></a></i></span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <!-- DataTable ends -->

                    <!-- add new sidebar starts -->
                    <form action="{{route('template.post.create')}}" method="post" enctype="multipart/form-data">
                      @csrf
                    <div class="add-new-data-sidebar">
                        <div class="overlay-bg"></div>
                        <div class="add-new-data">
                            <div class="div mt-2 px-2 d-flex new-data-title justify-content-between">
                                <div>
                                    <h4 class="text-uppercase">Create New Theme</h4>
                                </div>
                                <div class="hide-data-sidebar">
                                    <i class="feather icon-x"></i>
                                </div>
                            </div>
                            <div class="data-items pb-3">
                                <div class="data-fields px-2">
                                    <div class="row">
                                        <div class="col-sm-12 data-field-col">
                                            <label for="data-name">Template Name</label>
                                            <input type="text" name="name" class="form-control" id="data-name">
                                             <span class="text-danger">{{ $errors->first('name') }}</span>
                                        </div>
                                         <div class="col-sm-12 data-field-col">
                                            <label for="data-name">Choose Theme Image</label>
                                            <input type="file" name="url" class="form-control" id="data-name">
                                             <span class="text-danger">{{ $errors->first('url') }}</span>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="add-data-footer d-flex justify-content-around px-3 mt-2">
                                <div class="add-data-btn">
                                    <button type="submit"  class="btn btn-primary ">Add New Template</button>
                                </div>
                                <div class="cancel-data-btn">
                                    <button class="btn btn-outline-danger">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                  </form>
                    <!-- add new sidebar ends -->
                </section>
                <!-- Data list view end -->
  {{-- Data list view end --}}
@endsection
@push('vendor-script')
{{-- vendor js files --}}
        <script src="{{ asset('app-assets/vendors/js/extensions/dropzone.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script> 
@endpush
@push('page-script')
        {{-- Page js files --}}
<script src="{{ asset('app-assets/js/scripts/ui/data-list-view.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.buttons.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js')}}"></script>
@endpush
