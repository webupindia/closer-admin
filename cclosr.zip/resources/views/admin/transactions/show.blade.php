@extends('admin.layouts.app')
@section('title', 'Show Transaction')
@push('page-style')
        {{-- Page css files --}}
        <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/pages/app-user.css') }}">
@endpush
@section('content')
  <nav aria-label="breadcrumb">
     <ol class="breadcrumb breadcrumb-pipes">
      <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">Home</a></li>
      <li class="breadcrumb-item"><a href="{{route('show-transactions')}}">Transaction</a></li>
      <li class="breadcrumb-item active" aria-current="page">Transaction Details</li>
      </ol>
  </nav>
{{-- Page Users View --}}
                <section class="page-users-view">
                    <div class="row">
                        <!-- account start -->
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title text-tp-primary">Transaction Details</div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-12 col-sm-12 col-md-6 col-lg-6">
                                            <table>
                                                <tr>
                                                    <td class="font-weight-bold">Name</td>
                                                    <td>Ashwini Upadhyay</td>
                                                </tr>
                                                <tr>
                                                    <td class="font-weight-bold">Email</td>
                                                    <td>admin123@gmail.com</td>
                                                </tr>
                                                 <tr>
                                                    <td class="font-weight-bold">Phone Number</td>
                                                    <td>9009009009</td>
                                                </tr>
                                                 <tr>
                                                    <td class="font-weight-bold">Status</td>
                                                    <td>Active</td>
                                                </tr>
                                               
                                            </table>
                                        </div>
                                        <div class="col-12 col-md-12 col-lg-5">
                                            <table class="ml-0 ml-sm-0 ml-lg-0">
                                                <tr>
                                                    <td class="font-weight-bold">Amount</td>
                                                    <td>$220</td>
                                                </tr>
                                                <tr>
                                                    <td class="font-weight-bold">Transaction Id</td>
                                                    <td>t3338vmvietbe888578</td>
                                                </tr>
                                                 <tr>
                                                    <td class="font-weight-bold"> Order Id </td>
                                                    <td>201137</td>
                                                </tr>
                                                 <tr>
                                                    <td class="font-weight-bold">Added On</td>
                                                    <td>3rd March , 2020 at 5:00PM</td>
                                                </tr>

                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- account end -->
                      
                    </div>
                </section>
                {{-- End Page Users View --}}
@endsection