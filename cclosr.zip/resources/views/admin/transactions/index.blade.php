@extends('admin.layouts.app')
@section('title', 'All Transactions ')

@push('vendor-style')
        {{-- vendor files --}}
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/charts/apexcharts.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/datatables.min.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/file-uploaders/dropzone.min.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/extensions/dataTables.checkboxes.css') }}">
@endpush
@push('page-style')
        {{-- Page css files --}}
        <link rel="stylesheet" href="{{ asset('app-assets/css/plugins/file-uploaders/dropzone.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/css/pages/data-list-view.css') }}">
         <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/core/menu/menu-types/vertical-menu.css') }}">
@endpush

@section('content')
<nav aria-label="breadcrumb">
     <h2 class="content-header-title float-left mb-0">Transactions</h2>
     <ol class="breadcrumb breadcrumb-pipes">
        <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Transactions</li>
    </ol>
</nav>
{{-- Data list view starts --}}
  <!-- Data list view starts -->
                <section id="data-list-view" class="data-list-view-header">
                    <!-- DataTable starts -->
                    <div class="table-responsive">
                        <table class="table data-list-view">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>NAME</th>
                                    <th>Email</th>
                                    <th>MOBILE NO.</th>
                                    <th>AMOUNT</th>
                                    <th>ADDED ON</th>
                                    <th>STATUS</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><b>1</b></td>
                                    <td>Vikas Jawla</td>
                                    <td>demo123@gmail.com</td>
                                    <td>8009900994</td>
                                    <td>$220</td>
                                    <td>03/02/20 5:00PM</td>
                                    <td>
                                       <div class="custom-control custom-switch switch-lg custom-switch-success">
                                                <input type="checkbox" class="custom-control-input" id="customSwitch100">
                                                <label class="custom-control-label" for="customSwitch100">
                                                    <span class="switch-text-left">Active</span>
                                                    <span class="switch-text-right">Inactive</span>
                                                </label>
                                            </div>
                                    </td>
                                    <td class="product-action">
                                        <a href="{{route('show-transactions')}}"><span class="action-eye"><i class="feather icon-eye font-weight-bold"></i></span></a>
                                        <a href="#"><span class="action-delete"><i class="feather icon-trash font-weight-bold"></i></span></a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!-- DataTable ends -->
                </section>
                <!-- Data list view end -->
  {{-- Data list view end --}}
@endsection
@push('vendor-script')
{{-- vendor js files --}}
        <script src="{{ asset('app-assets/vendors/js/extensions/dropzone.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script>
      
      
@endpush
@push('page-script')
        {{-- Page js files --}}
        <script src="{{ asset('app-assets/js/scripts/ui/data-list-view.js') }}"></script>
@endpush
