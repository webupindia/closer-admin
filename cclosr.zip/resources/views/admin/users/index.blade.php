@extends('admin.layouts.app')
@section('title', 'All Users ')

@push('vendor-style')
{{-- vendor files --}}
<link rel="stylesheet" href="{{ asset('app-assets/vendors/css/charts/apexcharts.css') }}">
<link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/datatables.min.css') }}">
<link rel="stylesheet" href="{{ asset('app-assets/vendors/css/file-uploaders/dropzone.min.css') }}">
<link rel="stylesheet"
    href="{{ asset('app-assets/vendors/css/tables/datatable/extensions/dataTables.checkboxes.css') }}">    
@endpush
@push('page-style')
{{-- Page css files --}}
<link rel="stylesheet" href="{{ asset('app-assets/css/plugins/file-uploaders/dropzone.css') }}">
<link rel="stylesheet" href="{{ asset('app-assets/css/pages/data-list-view.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/core/menu/menu-types/vertical-menu.css') }}">
<!--Start  Session Error Show Side Panel -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

@if(Session::has('errors'))
<script>
    $(document).ready(function() {
        $('.add-new-data').addClass('show');
        $('.overlay-bg').addClass('show');
    });
</script>
@endif
<!--End  Session Error Show Side Panel -->
@endpush

@section('content')
<nav aria-label="breadcrumb">
    <h2 class="content-header-title float-left mb-0">Users</h2>
    <ol class="breadcrumb breadcrumb-pipes">
        <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Users</li>
    </ol>
</nav>
{{-- Data list view starts --}}
<section id="data-list-view" class="data-list-view-header">
    <!-- DataTable starts -->
    <div class="table-responsive">
        <table class="table data-list-view">
            <thead>
                <tr>
                    <th>S.No.</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Registeration Type</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($Users as $item)
                <tr>
                    <td><b>{{ $loop->iteration }}</b></td>
                    <td>{{ $item->name}}<br>
                        <sub>Username: {{ $item->username}}</sub>
                    </td>
                    <td>{{ $item->email}}</td>
                    <td>{{ $item->phone}}</td>
                    <td>
                      {{ $item->registeration_type}}
                    </td>
                    <td>
                        @if($item->active==1)
                            <a href="{{ route('user.get.inactive',['id'=>Crypt::encrypt($item->id)]) }}">
                            <div class="chip chip-success">
                                <div class="chip-body">
                                <div class="chip-text">
                                        Active
                                </div>
                                </div>
                            </div>
                        </a>
                            @else
                            <a href="{{ route('user.get.active',['id'=>Crypt::encrypt($item->id)]) }}">
                            <div class="chip chip-error">
                                <div class="chip-body">
                                <div class="chip-text">
                                        Inactive
                                </div>
                                </div>
                            </div>
                            </a>
                        @endif
                    </td>
                    <td class="product-action">
                            <span class="action-view"><a href="{{route('user.get.edit',['id'=>Crypt::encrypt($item->id)])}}"><i class="feather icon-edit"></i></a></span>
                            <span class="action-view"><a href="{{route('user.get.show',['id'=>Crypt::encrypt($item->id)])}}"><i class="feather icon-eye"></i></a></span>
                            <span class="action"><a href="{{route('user.get.delete',['id'=>Crypt::encrypt($item->id)])}}" onclick="return confirm('Are you sure you want to delete this user?')"><i class="feather icon-trash"></a></i></span>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <!-- DataTable ends -->

    <!-- add new sidebar starts -->
    <form action="{{route('user.get.create')}}" method="post">
        @csrf
        <div class="add-new-data-sidebar">
            <div class="overlay-bg"></div>
            <div class="add-new-data" id="add-new">
                <div class="div mt-2 px-2 d-flex new-data-title justify-content-between">
                    <div>
                        <h4 class="text-uppercase">Create New User</h4>
                    </div>
                    <div class="hide-data-sidebar">
                        <i class="feather icon-x"></i>
                    </div>
                </div>
                <div class="data-items pb-3">
                    <div class="data-fields px-2">
                        <div class="row">
                            <div class="col-sm-12 col-md-6 data-field-col">
                                <label for="data-name">Name</label>
                                <input type="text" name="name" class="form-control" value="{{old('name')}}" id="data-name">
                                <span class="text-danger">{{ $errors->first('name') }}</span>
                            </div>
                            <div class="col-sm-12 col-md-6 data-field-col">
                                <label for="data-username">Username</label>
                                <input type="text" name="username" class="form-control" value="{{old('username')}}" id="data-username">
                                <span class="text-danger">{{ $errors->first('username') }}</span>
                            </div>
                            <div class="col-sm-12 col-md-6 data-field-col">
                                <label for="data-email">Email Id</label>
                                <input type="text" name="email" class="form-control"  value="{{old('email')}}" id="data-email">
                                <span class="text-danger">{{ $errors->first('email') }}</span>
                            </div>
                            <div class="col-sm-12 col-md-6 data-field-col">
                                <label for="data-password">Password</label>
                                <input type="password" name="password" class="form-control"  value="{{old('password')}}" id="data-password">
                                <span class="text-danger">{{ $errors->first('password') }}</span>
                            </div>
                            <div class="col-sm-12 col-md-6 data-field-col">
                                <label for="data-phone">Mobile No</label>
                                <input type="text" name="phone" class="form-control"  value="{{old('phone')}}" id="data-phone">
                                <span class="text-danger">{{ $errors->first('phone') }}</span>
                            </div>
                            <div class="col-sm-12 col-md-6 data-field-col">
                                <label for="data-dob">Date Of Birth</label>
                                <input type="date" name="dob" class="form-control"  value="{{old('dob')}}" id="data-dob">
                                <span class="text-danger">{{ $errors->first('dob') }}</span>
                            </div>
                             <div class="col-sm-12 col-md-6 data-field-col">
                                <label for="data-type">City</label>
                                <input type="text" name="city" class="form-control" value="{{old('city')}}" id="data-type">
                                <span class="text-danger">{{ $errors->first('city') }}</span>
                            </div>

                            <div class="col-sm-12  data-field-col">
                                <div class="form-group">
                                    <label>Gender</label>
                                    <ul class="list-unstyled mb-0">
                                        <li class="d-inline-block mr-2">
                                            <fieldset>
                                                <div class="vs-radio-con">
                                                    <input type="radio" name="gender" checked value="Male">
                                                    <span class="vs-radio">
                                                        <span class="vs-radio--border"></span>
                                                        <span class="vs-radio--circle"></span>
                                                    </span>
                                                    Male
                                                </div>
                                            </fieldset>
                                        </li>
                                        <li class="d-inline-block mr-2">
                                            <fieldset>
                                                <div class="vs-radio-con">
                                                    <input type="radio" name="gender" value="Female">
                                                    <span class="vs-radio">
                                                        <span class="vs-radio--border"></span>
                                                        <span class="vs-radio--circle"></span>
                                                    </span>
                                                    Female
                                                </div>
                                            </fieldset>
                                        </li>
                                        <li class="d-inline-block mr-2">
                                            <fieldset>
                                                <div class="vs-radio-con">
                                                    <input type="radio" name="gender" value="Other">
                                                    <span class="vs-radio">
                                                        <span class="vs-radio--border"></span>
                                                        <span class="vs-radio--circle"></span>
                                                    </span>
                                                    Other
                                                </div>
                                            </fieldset>
                                        </li>

                                    </ul>
                                    <span class="text-danger">{{ $errors->first('gender') }}</span>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="add-data-footer d-flex justify-content-around px-3 mt-2">
                    <div class="add-data-btn">
                        <button type="submit" class="btn btn-primary">Add User</button>
                    </div>
                    <div class="cancel-data-btn">
                        <button class="btn btn-outline-danger">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <!-- add new sidebar ends -->
</section>
{{-- Data list view end --}}

@endsection
@push('vendor-script')
{{-- vendor js files --}}
<script src="{{ asset('app-assets/vendors/js/extensions/dropzone.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script>
@endpush
@push('page-script')
{{-- Page js files --}}
<script src="{{ asset('app-assets/js/scripts/ui/data-list-view.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.buttons.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js')}}"></script>
@endpush


