@extends('admin.layouts.app')
@section('title', 'Unverified Users ')

@push('vendor-style')
{{-- vendor files --}}
<link rel="stylesheet" href="{{ asset('app-assets/vendors/css/charts/apexcharts.css') }}">
<link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/datatables.min.css') }}">
<link rel="stylesheet" href="{{ asset('app-assets/vendors/css/file-uploaders/dropzone.min.css') }}">
<link rel="stylesheet"
    href="{{ asset('app-assets/vendors/css/tables/datatable/extensions/dataTables.checkboxes.css') }}">    
@endpush
@push('page-style')
{{-- Page css files --}}
<link rel="stylesheet" href="{{ asset('app-assets/css/plugins/file-uploaders/dropzone.css') }}">
<link rel="stylesheet" href="{{ asset('app-assets/css/pages/data-list-view.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/core/menu/menu-types/vertical-menu.css') }}">
@endpush

@section('content')
<nav aria-label="breadcrumb">
    <h2 class="content-header-title float-left mb-0">Users</h2>
    <ol class="breadcrumb breadcrumb-pipes">
        <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Unverified Users</li>
    </ol>
</nav>
{{-- Data list view starts --}}
<section id="data-list-view" class="data-list-view-header">
    <!-- DataTable starts -->
    <div class="table-responsive">
        <table class="table data-list-view">
            <thead>
                <tr>
                    <th>S.No.</th>
                    <th>Name</th>
                    <th>Email Verification</th>
                    <th>Added On</th>
                </tr>
            </thead>
            <tbody>
                @foreach($unverifiedUsers as $item)
                <tr>
                    <td><b>{{ $loop->iteration }}</b></td>
                    <td>{{ $item->name}}<br>
                        <sub>Username: {{ $item->username}}</sub>
                    </td>
                    <td>
                        @if($item->email_verification==1)
                            <a href="{{ route('user.get.unverified',['id'=>Crypt::encrypt($item->id)]) }}">
                            <div class="chip chip-success">
                                <div class="chip-body">
                                <div class="chip-text">
                                        Verified
                                </div>
                                </div>
                            </div>
                        </a>
                            @else
                            <a href="{{ route('user.get.verified',['id'=>Crypt::encrypt($item->id)]) }}">
                            <div class="chip chip-error">
                                <div class="chip-body">
                                <div class="chip-text">
                                        Unverified
                                </div>
                                </div>
                            </div>
                            </a>
                        @endif
                    </td>
                    <td>
                       {{ date('dS F,Y',strtotime($item->created_at)) }} at {{ date('g:ia',strtotime($item->created_at)) }}
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <!-- DataTable ends -->
</section>
{{-- Data list view end --}}

@endsection
@push('vendor-script')
{{-- vendor js files --}}
<script src="{{ asset('app-assets/vendors/js/extensions/dropzone.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script>
@endpush
@push('page-script')
{{-- Page js files --}}
<script src="{{ asset('app-assets/js/scripts/ui/data-list-view.js') }}"></script>
@endpush