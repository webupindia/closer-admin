@extends('admin.layouts.app')
@section('title', 'Edit User')
@push('page-style')
{{-- Page css files --}}
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/pages/app-user.css') }}">
@endpush
@section('content')
<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-pipes">
        <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">home</a></li>
        <li class="breadcrumb-item"><a href="{{route('user.get.index')}}">Users</a></li>
        <li class="breadcrumb-item active" aria-current="page">User Edit</li>
    </ol>
</nav>
{{-- users edit start --}}
<section class="users-edit">
    <div class="card">
        <div class="card-header">
            <div class="card-title text-tp-primary">Edit User</div>
        </div>
        <div class="card-content">
            <div class="card-body">
                <div class="tab-content">
                    <div class="tab-pane active" id="account" aria-labelledby="account-tab" role="tabpanel">

                        <!-- users edit account form start -->
                        <form novalidate action="{{route('user.post.update')}}" method="post">
                            @csrf
                            <div class="row">
                                <div class="col-sm-12 col-md-6">
                                   <div class="form-group">
                                    <label for="name">Name </label>
                                     <input type="text" name="name" value="{{$getResult->name}}" class="form-control" id="name">
                                    <span class="text-danger">{{ $errors->first('name') }}</span>
                                    </div>
                                </div>
                                 <div class="col-sm-12 col-md-6">
                                   <div class="form-group">
                                    <label for="username">Username</label>
                                     <input type="text" name="username" value="{{$getResult->username}}" class="form-control" id="username">
                                       <span class="text-danger">{{ $errors->first('username') }}</span>
                                    </div>
                                </div>
                                 <div class="col-sm-12 col-md-6">
                                   <div class="form-group">
                                    <label for="email">Email</label>
                                     <input type="text" class="form-control" name="email" value="{{$getResult->email}}" id="email">
                                       <span class="text-danger">{{ $errors->first('email') }}</span>
                                    </div>
                                </div>
                                 <div class="col-sm-12 col-md-6">
                                   <div class="form-group">
                                    <label for="password">Password</label>
                                     <input type="password" name="password" value="{{$getResult->password}}" class="form-control" id="password">
                                       <span class="text-danger">{{ $errors->first('password') }}</span>
                                    </div>
                                </div>
                                 <div class="col-sm-12 col-md-6">
                                   <div class="form-group">
                                    <label for="phone">Phone Number </label>
                                     <input type="text" name="phone" value="{{$getResult->phone}}" class="form-control" id="phone">
                                       <span class="text-danger">{{ $errors->first('phone') }}</span>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                   <div class="form-group">
                                    <label for="data-dob">Date Of Birth</label>
                                      <input type="date" name="dob" value="{{$getResult->dob}}" class="form-control" id="data-dob">
                                        <span class="text-danger">{{ $errors->first('dob') }}</span>
                                    </div>
                                </div>
                                 <div class="col-sm-12 col-md-6">
                                   <div class="form-group">
                                    <label for="data-type">Registeration Type</label>
                                      <select name="registeration_type" id="data-type" class="form-control" onchange="yesnoCheck(this);">
                                    <option value="">Choose Registeration Type</option>
                                    <option value="Google" @if ($getResult->registeration_type =="Google" ) {{ 'selected' }} @endif>Google</option>
                                    <option value="Facebook" @if ($getResult->registeration_type =="Facebook" ) {{ 'selected' }} @endif>Facebook</option>
                                   </select>
                                     <span class="text-danger">{{ $errors->first('registeration_type') }}</span>
                                    </div>
                                </div>  
                                 <div class="col-sm-12 col-md-6">
                                   <div class="form-group">
                                    <label for="city">City</label>
                                      <input type="text" name="city" value="{{$getResult->city}}" class="form-control" id="city">
                                        <span class="text-danger">{{ $errors->first('city') }}</span>
                                    </div>
                                     <input type="hidden" name="id" value="{{Crypt::encrypt($getResult->id)}}">
                                </div> 
                                  <div class="col-sm-12  data-field-col">
                                <div class="form-group">
                                    <label>Gender</label>
                                    <ul class="list-unstyled mb-0">
                                        <li class="d-inline-block mr-2">
                                            <fieldset>
                                                <div class="vs-radio-con">
                                                    <input type="radio"  name="gender" checked value="Male" {{ $getResult->gender == 'Male' ? 'checked' : ''}}>
                                                    <span class="vs-radio">
                                                        <span class="vs-radio--border"></span>
                                                        <span class="vs-radio--circle"></span>
                                                    </span>
                                                    Male
                                                </div>
                                            </fieldset>
                                        </li>
                                        <li class="d-inline-block mr-2">
                                            <fieldset>
                                                <div class="vs-radio-con">
                                                    <input type="radio" name="gender" value="Female" {{ $getResult->gender == 'Female' ? 'checked' : ''}}>
                                                    <span class="vs-radio">
                                                        <span class="vs-radio--border"></span>
                                                        <span class="vs-radio--circle"></span>
                                                    </span>
                                                    Female
                                                </div>
                                            </fieldset>
                                        </li>
                                        <li class="d-inline-block mr-2">
                                            <fieldset>
                                                <div class="vs-radio-con">
                                                    <input type="radio" name="gender" value="Other" {{ $getResult->gender == 'Other' ? 'checked' : ''}}>
                                                    <span class="vs-radio">
                                                        <span class="vs-radio--border"></span>
                                                        <span class="vs-radio--circle"></span>
                                                    </span>
                                                    Other
                                                </div>
                                            </fieldset>
                                        </li>

                                    </ul>
                                    <span class="text-danger">{{ $errors->first('gender') }}</span>
                                </div>
                            </div>
                        
                                <div class="col-12 d-flex flex-sm-row flex-column  mt-1">
                                    <button type="submit" class="btn btn-primary glow mb-1 mb-sm-0 mr-0 mr-sm-1">Edit User</button>
                                    <button class="btn btn-outline-warning">Clear</button>

                                </div>
                            </div>
                        </form>
                        <!-- users edit account form ends -->
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
{{-- users edit End --}}
@endsection