@extends('admin.layouts.app')
@section('title', 'User Details')
@push('page-style')
{{-- Page css files --}}
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/pages/app-user.css') }}">
<link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/datatables.min.css') }}">
<link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/extensions/dataTables.checkboxes.css') }}">  
@endpush
@section('content')
<nav aria-label="breadcrumb">
     <h2 class="content-header-title float-left mb-0">Users</h2>
     <ol class="breadcrumb breadcrumb-pipes">
        <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">Home</a></li>
        <li class="breadcrumb-item"><a href="{{route('user.get.index')}}">Users</a></li>
        <li class="breadcrumb-item active" aria-current="page">User Details</li>
    </ol>
</nav>
{{-- Page Users View --}}
<section class="page-users-view">
    <div class="row">
        <!-- account start -->
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title text-tp-primary">User Details</div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-6 col-lg-6">
                            <table>
                                <tr>
                                    <td class="font-weight-bold">Name</td>
                                    <td>{{$SpecificUser->name}}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Username</td>
                                    <td><mark>{{$SpecificUser->username}}</mark></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Email</td>
                                    <td><a href="mailto:{{$SpecificUser->email}}">
                                        {{$SpecificUser->email}}
                                    </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Phone Number</td>
                                    <td>
                                            <a href="tel:{{$SpecificUser->phone}}">
                                        {{$SpecificUser->phone ?? '-'}}
                                            </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Signed Up On</td>
                                    <td>
                                            {{ date('dS F,Y',strtotime($SpecificUser->created_at)) }} at {{ date('g:ia',strtotime($SpecificUser->created_at)) }}
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-12 col-md-12 col-lg-5">
                            <table class="ml-0 ml-sm-0 ml-lg-0">
                                <tr>
                                    <td class="font-weight-bold">Age</td>
                                    <td> {{ \Carbon\Carbon::parse($SpecificUser->dob)->diff(\Carbon\Carbon::now())->format('%y Years Old')}}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Gender</td>
                                    <td>{{$SpecificUser->gender}}</td>
                                </tr>
                                 @foreach($getCloserRequestCount as $item)
                                  <tr>
                                    <td class="font-weight-bold">Free Ccloser <br>Request Count</td>
                                    <td><br><b>{{$item->remaining_count}}</b></td>
                                   
                                </tr>
                                 @endforeach
                                <tr>
                                    <td class="font-weight-bold">Registeration Type</td>
                                    <td>{{$SpecificUser->registeration_type}}</td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Status</td>
                                    <td>
                                        @if($SpecificUser->active=='0')
                                       <div class="chip chip-danger">
                                            <div class="chip-body">
                                                <div class="chip-text">InActive</div>
                                            </div>
                                        </div>
                                        @elseif($SpecificUser->active=='1')
                                          <div class="chip chip-success">
                                            <div class="chip-body">
                                                <div class="chip-text">Active</div>
                                            </div>
                                        </div>
                                       @endif
                                    </td>
                                </tr>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- account end -->

                     {{-- Show friends --}}
                     @if(count($getFriends)>0)
                     <div class="col-12">
                             <div class="card">
                                 <div class="card-header">
                                     <div class="card-title text-tp-primary">Friend Request Details</div>
                                 </div>
                                 <div class="card-body">
                                     <div class="row">
                                             <div class="col-12 col-md-12 col-lg-12">
                                                     <div class="table-responsive">
                                                             <table class="table zero-configuration">
                                                                     <thead>
                                                                             <tr>
                                                                                 <th>S. No.</th>
                                                                                 <th>Request Sent to</th>
                                                                                 <th>Request Status</th>
                                                                                 <th>Sent On</th>
                                                                             </tr>
                                                                         </thead>
                                                                         <tbody>
                                                                             @foreach ($getFriends as $item)          
                                                                             <tr>
                                                                                 <td>{{ $loop->iteration }}</td>
                                                                                 <td>
                                                                                    <a href="{{route('user.get.show',['id'=>Crypt::encrypt($item->receiver->id)])}}" target="_blank"> 
                                                                                    {{$item->receiver->name }} </a> <br>
                                                                                    <sub>username: {{$item->receiver->username}}</sub>
                                                                                 </td>
                                                                                 <td>
                                                                                        @if($item->status==1)
                                                                                        <div class="chip chip-success">
                                                                                            <div class="chip-body">
                                                                                            <div class="chip-text">
                                                                                                    Accepted
                                                                                            </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        @else
                                                                                        <div class="chip chip-warning">
                                                                                            <div class="chip-body">
                                                                                            <div class="chip-text">
                                                                                                    Pending
                                                                                            </div>
                                                                                            </div>
                                                                                        </div>
                                                                                     
                                                                                    @endif
                                                                                 </td>
                                                                                 <td> {{ date('dS F,Y',strtotime($item->created_at)) }} at {{ date('g:ia',strtotime($item->created_at)) }}</td>
                                                                             </tr>
                                                                             @endforeach
                                                                         </tbody>
                                                             </table>
                                                     </div>
                                             </div>
                                     </div>
                                 </div>
                             </div>
                     </div>
                     @endif
                     {{-- Ends Show Friends --}}

    </div>
</section>
{{-- End Page Users View --}}
@endsection
@push('page-script')
        <script src="{{ asset('app-assets/js/scripts/pages/app-user.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.buttons.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/dataTables.select.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js') }}"></script>
        {{-- Page js files --}}
        <script src="{{ asset('app-assets/js/scripts/datatables/datatable.js') }}"></script>
@endpush