@extends('admin.layouts.app')
@section('title',__('All Ccloser Request | Ccloser Admin'))
@push('vendor-style')
        {{-- vendor files --}}
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/charts/apexcharts.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/datatables.min.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/file-uploaders/dropzone.min.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/extensions/dataTables.checkboxes.css') }}">
@endpush
@push('page-style')
        {{-- Page css files --}}
        <link rel="stylesheet" href="{{ asset('app-assets/css/plugins/file-uploaders/dropzone.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/css/pages/data-list-view.css') }}">
         <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/core/menu/menu-types/vertical-menu.css') }}">
@endpush

@section('content')
<div class="">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-left mb-0">Image Morphing Requests</h2>
                            <div class="breadcrumb-wrapper col-12">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active">All Ccloser Requests
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
    
            </div>
            <div class="content-body">
{{-- Data list view starts --}}
  <!-- Data list view starts -->
                <section id="data-list-view" class="data-list-view-header">
                    <div class="action-btns d-none">
                        <div class="btn-dropdown mr-1 mb-1">
                            <div class="btn-group dropdown actions-dropodown">
                               
                            </div>
                        </div>
                    </div>

                    <!-- DataTable starts -->
                    <div class="table-responsive">
                        <table class="table data-list-view">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>SENDER DETAILS</th>
                                    <th>RECEIVER DETAILS</th>
                                    <th>TEMPLATE</th>
                                    <th>STATUS</th>
                                    <th>SENT ON</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($getRequest as $item)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>
                                            <a href="{{route('user.get.show',['id'=>Crypt::encrypt($item->sender->id)])}}" target="_blank"> 
                                                    {{$item->sender->name }} </a> <br>
                                                    <sub>username: {{$item->sender->username}}</sub>
                                    </td>
                                      <td>
                                            <a href="{{route('user.get.show',['id'=>Crypt::encrypt($item->receiver->id)])}}" target="_blank"> 
                                                    {{$item->receiver->name }} </a> <br>
                                                    <sub>username: {{$item->receiver->username}}</sub>
                                    </td>
                                    <td> 
                                    <img src="{{ asset('storage/template/'.$item->template->url) }}" width="100" class="img-responsive">  
                                    </td>
                                    <td>
                                            @if($item->status==1)
                                            <div class="chip chip-success">
                                                <div class="chip-body">
                                                <div class="chip-text">
                                                        Accepted
                                                </div>
                                                </div>
                                            </div>
                                            @else
                                            <div class="chip chip-warning">
                                                <div class="chip-body">
                                                <div class="chip-text">
                                                        Pending
                                                </div>
                                                </div>
                                            </div>
                                         
                                        @endif
                                    </td>
                                  <td>{{ date('dS F,Y',strtotime($item->created_at)) }} at {{ date('g:ia',strtotime($item->created_at)) }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <!-- DataTable ends -->
                </section>
  {{-- Data list view end --}}
        </div>
    </div>
</div>
@endsection
@push('vendor-script')
{{-- vendor js files --}}
        <script src="{{ asset('app-assets/vendors/js/extensions/dropzone.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script>
      
      
@endpush
@push('page-script')
        {{-- Page js files --}}
        <script src="{{ asset('app-assets/js/scripts/ui/data-list-view.js') }}"></script>
@endpush
