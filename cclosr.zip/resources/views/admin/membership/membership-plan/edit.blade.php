@extends('admin.layouts.app')
@section('title', 'Edit Membership Plan')
@push('page-style')
{{-- Page css files --}}
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/pages/app-user.css') }}">
@endpush
@section('content')
<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-pipes">
        <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">Home</a></li>
        <li class="breadcrumb-item"><a href="{{route('membership-plan.get.index')}}">Membership</a></li>
        <li class="breadcrumb-item active" aria-current="page">Membership Plan Edit</li>
    </ol>
</nav>
{{-- users edit start --}}
<section class="users-edit">
    <div class="card">
        <div class="card-header">
            <div class="card-title text-tp-primary">Edit Membership Plan</div>
        </div>
        <div class="card-content">
            <div class="card-body">
                <div class="tab-content">
                    <div class="tab-pane active" id="account" aria-labelledby="account-tab" role="tabpanel">

                        <!-- users edit account form start -->
                        <form novalidate action="{{route('membership-plan.post.update')}}" method="post">
                            @csrf
                            <div class="row">
                                <div class="col-sm-12 col-md-6">
                                   <div class="form-group">
                                    <label for="name">Amount </label>
                                     <input type="text" name="amount" value="{{$getResult->amount}}" class="form-control" id="name">
                                    <span class="text-danger">{{ $errors->first('amount') }}</span>
                                    </div>
                                </div>
                                 <div class="col-sm-12 col-md-6">
                                   <div class="form-group">
                                    <label for="credit">Credit</label>
                                     <input type="text" name="credit" value="{{$getResult->credit}}" class="form-control" id="credit">
                                       <span class="text-danger">{{ $errors->first('credit') }}</span>
                                    </div>
                                </div>
                                <input type="hidden" name="id" value="{{Crypt::encrypt($getResult->id)}}">
                                <div class="col-12 d-flex flex-sm-row flex-column  mt-1">
                                    <button type="submit" class="btn btn-primary glow mb-1 mb-sm-0 mr-0 mr-sm-1">Edit User</button>
                                    <button class="btn btn-outline-warning">Clear</button>

                                </div>
                            </div>
                        </form>
                        <!-- users edit account form ends -->
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
{{-- users edit End --}}
@endsection