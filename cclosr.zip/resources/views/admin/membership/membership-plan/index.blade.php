@extends('admin.layouts.app')
@section('title', 'All Template ')

@push('vendor-style')
        {{-- vendor files --}}
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/charts/apexcharts.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/datatables.min.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/file-uploaders/dropzone.min.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/extensions/dataTables.checkboxes.css') }}">
@endpush
@push('page-style')
        {{-- Page css files --}}
        <link rel="stylesheet" href="{{ asset('app-assets/css/plugins/file-uploaders/dropzone.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/css/pages/data-list-view.css') }}">
         <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/core/menu/menu-types/vertical-menu.css') }}">
          <!--Start  Session Error Show Side Panel -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

        @if(Session::has('errors'))
        <script>
            $(document).ready(function() {
                $('.add-new-data').addClass('show');
                $('.overlay-bg').addClass('show');
            });
        </script>
        @endif
        <!--End  Session Error Show Side Panel -->         
@endpush

@section('content')
<nav aria-label="breadcrumb">
     <h2 class="content-header-title float-left mb-0">Membership Plan</h2>
     <ol class="breadcrumb breadcrumb-pipes">
        <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Membership Plan</li>
    </ol>
</nav>
{{-- Data list view starts --}}
  <!-- Data list view starts -->
                <section id="data-list-view" class="data-list-view-header">
                    <!-- DataTable starts -->
                    <div class="table-responsive">
                        <table class="table data-list-view">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>AMOUNT</th>
                                    <th>CREDIT</th>
                                    <th>STATUS</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
                                  @foreach($memberships as $membership)
                                <tr id="deleteRow">
                                    <td><b>{{ $loop->iteration }}</b></td>
                                    <td>$ {{ $membership->amount}}</td>
                                    <td>$ {{ $membership->credit}}</td>
                                    <td>
                                       
                                        @if($membership->status==1)
                                            <a href="{{ route('membership-plan.get.inactive',['id'=>Crypt::encrypt($membership->id)]) }}">
                                            <div class="chip chip-success">
                                                <div class="chip-body">
                                                <div class="chip-text">
                                                        Active
                                                </div>
                                                </div>
                                            </div>
                                        </a>
                                            @else
                                            <a href="{{ route('membership-plan.get.active',['id'=>Crypt::encrypt($membership->id)]) }}">
                                            <div class="chip chip-error">
                                                <div class="chip-body">
                                                <div class="chip-text">
                                                        Inactive
                                                </div>
                                                </div>
                                            </div>
                                            </a>
                                        @endif
                                    </td>
                                    <td class="product-action">
                                         <span class="action-view"><a href="{{route('membership-plan.get.edit',['id'=>Crypt::encrypt($membership->id)])}}"><i class="feather icon-edit"></i></a></span>
                                        <span class="action"><a href="{{route('membership-plan.get.delete',['id'=>Crypt::encrypt($membership->id)])}}" onclick="return confirm('Are you sure you want to delete this membership plan?')"><i class="feather icon-trash"></a></i></span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <!-- DataTable ends -->

                    <!-- add new sidebar starts -->
                    <form action="{{route('membership-plan.get.create')}}" method="post" enctype="multipart/form-data">
                      @csrf
                    <div class="add-new-data-sidebar">
                        <div class="overlay-bg"></div>
                        <div class="add-new-data">
                            <div class="div mt-2 px-2 d-flex new-data-title justify-content-between">
                                <div>
                                    <h4 class="text-uppercase">Create Membership Plan</h4>
                                </div>
                                <div class="hide-data-sidebar">
                                    <i class="feather icon-x"></i>
                                </div>
                            </div>
                            <div class="data-items pb-3">
                                <div class="data-fields px-2">
                                    <div class="row">
                                        <div class="col-sm-12 data-field-col">
                                            <label for="data-amount">Amount</label>
                                            <input type="text" name="amount" class="form-control" id="data-amount">
                                             <span class="text-danger">{{ $errors->first('amount') }}</span>
                                        </div>
                                         <div class="col-sm-12 data-field-col">
                                            <label for="data-credit">Credit</label>
                                            <input type="text" name="credit" class="form-control" id="data-credit">
                                             <span class="text-danger">{{ $errors->first('credit') }}</span>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="add-data-footer d-flex justify-content-around px-3 mt-2">
                                <div class="add-data-btn">
                                    <button type="submit"  class="btn btn-primary ">Add Membership Plan</button>
                                </div>
                                <div class="cancel-data-btn">
                                    <button class="btn btn-outline-danger">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                  </form>
                    <!-- add new sidebar ends -->
                </section>
                <!-- Data list view end -->
  {{-- Data list view end --}}
@endsection
@push('vendor-script')
{{-- vendor js files --}}
        <script src="{{ asset('app-assets/vendors/js/extensions/dropzone.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script> 
@endpush
@push('page-script')
        {{-- Page js files --}}
<script src="{{ asset('app-assets/js/scripts/ui/data-list-view.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.buttons.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js')}}"></script>
@endpush
