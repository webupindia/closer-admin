@extends('admin.layouts.app')
@section('title', 'Membership Credits ')

@push('vendor-style')
{{-- vendor files --}}
<link rel="stylesheet" href="{{ asset('app-assets/vendors/css/charts/apexcharts.css') }}">
<link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/datatables.min.css') }}">
<link rel="stylesheet" href="{{ asset('app-assets/vendors/css/file-uploaders/dropzone.min.css') }}">
<link rel="stylesheet"
    href="{{ asset('app-assets/vendors/css/tables/datatable/extensions/dataTables.checkboxes.css') }}">   
@endpush
@push('page-style')
{{-- Page css files --}}
<link rel="stylesheet" href="{{ asset('app-assets/css/plugins/file-uploaders/dropzone.css') }}">
<link rel="stylesheet" href="{{ asset('app-assets/css/pages/data-list-view.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/core/menu/menu-types/vertical-menu.css') }}">
@endpush

@section('content')
<nav aria-label="breadcrumb">
     <h2 class="content-header-title float-left mb-0">Membership Credits</h2>
     <ol class="breadcrumb breadcrumb-pipes">
        <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">Dashboard</a></li>
        <li class="breadcrumb-item active" aria-current="page">Membership Credits</li>
    </ol>
</nav>
{{-- Data list view starts --}}
<section id="data-list-view" class="data-list-view-header">
    <!-- DataTable starts -->
    <div class="table-responsive">
        <table class="table data-list-view">
            <thead>
                <tr>
                    <th>S.No.</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Available Credits</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($getRequest as $item)
                <tr>
                    <td><b>{{ $loop->iteration }}</b></td>
                    <td>{{ $item->member->name}}<br>
                        <sub>Username: {{ $item->member->username}}</sub>
                    </td>
                    <td>{{ $item->member->email}}</td>
                    <td>{{ $item->available_credit}}</td>
                    <td class="product-action">
                            <span class="action-view btn btn-primary"><a href="{{route('membership-credits.get.show',['id'=>Crypt::encrypt($item->id)])}}">History</a></span>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <!-- DataTable ends -->
</section>
{{-- Data list view end --}}
</div>
</div>
</div>
@endsection
@push('vendor-script')
{{-- vendor js files --}}
<script src="{{ asset('app-assets/vendors/js/extensions/dropzone.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script>
@endpush
@push('page-script')
{{-- Page js files --}}
<script src="{{ asset('app-assets/js/scripts/ui/data-list-view.js') }}"></script>
@endpush