@extends('admin.layouts.app')
@section('title', 'All Friends Request ')

@push('vendor-style')
        {{-- vendor files --}}
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/charts/apexcharts.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/datatables.min.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/file-uploaders/dropzone.min.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/extensions/dataTables.checkboxes.css') }}">
@endpush
@push('page-style')
        {{-- Page css files --}}
        <link rel="stylesheet" href="{{ asset('app-assets/css/plugins/file-uploaders/dropzone.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/css/pages/data-list-view.css') }}">
         <link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/core/menu/menu-types/vertical-menu.css') }}">
@endpush

@section('content')
<nav aria-label="breadcrumb">
     <h2 class="content-header-title float-left mb-0">Friend Request</h2>
     <ol class="breadcrumb breadcrumb-pipes">
        <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Friend Request</li>
    </ol>
</nav>
{{-- Data list view starts --}}
  <!-- Data list view starts -->
                <section id="data-list-view" class="data-list-view-header">
                    <div class="action-btns d-none">
                        <div class="btn-dropdown mr-1 mb-1">
                            <div class="btn-group dropdown actions-dropodown">
                               
                            </div>
                        </div>
                    </div>

                    <!-- DataTable starts -->
                    <div class="table-responsive">
                        <table class="table data-list-view">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>SENDER DETAILS</th>
                                    <th>RECEIVER DETAILS</th>
                                    <th>STATUS</th>
                                    <th>DATE & TIME</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><b>1</b></td>
                                    <td>
                                      <b>Name :</b> Vikas Jawla<br>
                                      <sub><b>Username : </b>demo12345</sub>
                                    </td>
                                      <td>
                                      <b>Name : </b> Ashwini Upadhyay<br>
                                      <sub><b>Username : </b> demo12345</sub>
                                    </td>
                                    <td> 
                                       <div class="chip chip-success">
                                            <div class="chip-body">
                                                <div class="chip-text">Active</div>
                                            </div>
                                        </div>
                                      </td>
                                  <td>3rd March , 2020 at 5:00PM</td>
                                </tr>
                               
                            </tbody>
                        </table>
                    </div>
                    <!-- DataTable ends -->
                </section>
                <!-- Data list view end -->
  {{-- Data list view end --}}
@endsection
@push('vendor-script')
{{-- vendor js files --}}
        <script src="{{ asset('app-assets/vendors/js/extensions/dropzone.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script>
      
      
@endpush
@push('page-script')
        {{-- Page js files --}}
        <script src="{{ asset('app-assets/js/scripts/ui/data-list-view.js') }}"></script>
@endpush
