@extends('admin.layouts.app')
@section('title', 'Monthly Transactions ')
@section('content')
<nav aria-label="breadcrumb">
     <h2 class="content-header-title float-left mb-0">Report Management</h2>
     <ol class="breadcrumb breadcrumb-pipes">
        <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Monthly Transactions</li>
    </ol>
</nav>
<!-- -----User Gained Chart------ -->
        @include('admin.include.charts.monthly-transactions')
@endsection

