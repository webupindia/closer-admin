@extends('admin.layouts.app')
@section('title',__('Notification'))


@push('vendor-style')
        {{-- vendor files --}}
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/charts/apexcharts.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/datatables.min.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/file-uploaders/dropzone.min.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/vendors/css/tables/datatable/extensions/dataTables.checkboxes.css') }}">
@endpush
@push('page-style')
        {{-- Page css files --}}
        <link rel="stylesheet" href="{{ asset('app-assets/css/plugins/file-uploaders/dropzone.css') }}">
        <link rel="stylesheet" href="{{ asset('app-assets/css/pages/data-list-view.css') }}">
        <style>
            .dt-buttons{
                display: none
            }
        </style>
@endpush

@section('content')

        <div class="content-header row">
            <div class="content-header-left col-md-9 col-12 mb-2">
                <div class="row breadcrumbs-top">
                    <div class="col-12">
                        <h2 class="content-header-title float-left mb-0">Notifications</h2>
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">Home</a>
                                </li>
                                <li class="breadcrumb-item active">All Notifications
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            <div class="media-body mt-50">
                <div class="col-12 d-flex mt-1 px-0">
                    @if(Auth::guard('admin')->user()->unreadNotifications->count()>0)
                    <a class="btn btn-sm btn-outline-warning ml-50 waves-effect waves-light"
                        href="{{route('notification.get.readAll')}}">Read All Notification</a>
                    @endif
                </div>
            </div>
{{-- Data list view starts --}}
<section id="data-list-view" class="data-list-view-header">
    {{-- DataTable starts --}}
    <div class="table-responsive">
      <table class="table data-list-view">
        <thead>
          <tr>
            <th>Sno.</th>
            <th>Type</th>
            <th>Title</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          @foreach($getNotify as $item)
           <tr>
              <td class="product-name">{{$loop->iteration}}</td>
              <td class="product-name">{{preg_replace('/(?<!\ )[A-Z]/', ' $0', class_basename($item->type))}}</td>
              <td class="product-name">{{$item->data['message']}}</td>
              <td class="product-category">{{date('F d,Y',strtotime($item->created_at)).' '.date('h:i a',strtotime($item->created_at))}}</td>
               <td class="product-action">
                <span class="action-delete h2"><a href="{{route('notification.get.read',['id'=>Crypt::encrypt($item->id)])}}"><i class="feather icon-trash-2 pr-1"></i></a></span>
              </td>
            </tr>
            @endforeach
        </tbody>
      </table>
    </div>
  </section>
  {{-- Data list view end --}}
@endsection
@push('vendor-script')
{{-- vendor js files --}}
        <script src="{{ asset('app-assets/vendors/js/extensions/dropzone.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.buttons.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script>
        <script src="{{ asset('app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js') }}"></script>
      
        
@endpush
@push('page-script')
        {{-- Page js files --}}
        <script src="{{ asset('app-assets/js/scripts/ui/data-list-view.js') }}"></script>
@endpush
