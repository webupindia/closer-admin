@extends('admin.layouts.app')
@section('title',__('Maintenance'))

 @section('content')

<section class="row">
    <div class="col-12 d-flex justify-content-center">
        <div class="card auth-card bg-transparent shadow-none rounded-0 mb-0 w-100">
            <div class="card-content">
                <div class="card-body">
                    <img src="{{ asset('app-assets/images/pages/maintenance-2.png') }}" class="img-fluid mx-auto d-block" alt="branding logo">
                    @if(is_null($appMaintenance))
                    <h1 class="font-large-2 my-1">App Live 😊</h1>
                    <div class="alert alert-success mb-2 text-left" role="alert">
                            Putting your app into maintenance mode will make it unavailable to the public.
                    </div>
                    @else
                    <h1 class="font-large-2 my-1 text-{{$appMaintenance->status==0?'success':'danger'}}">{{$appMaintenance->status==0 ? 'App Live 😊':'Under Maintenance 🛠️ '}}</h1>
                    <div class="alert alert-success mb-2 text-left" role="alert">
                            {{$appMaintenance->status==0 ? 'Putting your app into maintenance mode will make it unavailable to the public.':'Taking your app out of maintenance mode will make it accessible again.'}}
                    </div>
                    @endif
            
                    <div class="custom-control custom-switch switch-lg custom-switch-danger mr-2 mb-1">
                        <form method="POST" action=" {{ route('maintenance.post.store') }} ">
                            @if(is_null($appMaintenance))
                            <input type="hidden" name="status" value="1">
                            <button class="btn bg-gradient-danger mr-1 mb-1 waves-effect waves-light" type="submit">
                                Enable Maintenance Mode
                            </button>
                            @else
                           <input type="hidden" name="status" value="{{$appMaintenance->status==0 ?'1':'0'}}">
                           <button class="btn bg-gradient-{{$appMaintenance->status==0?'danger':'success'}} mr-1 mb-1 waves-effect waves-light" type="submit">
                                {{$appMaintenance->status==0 ?'Enable Maintenance Mode':'Disbale Maintenance Mode'}}
                           </button>
                           @endif
                            @csrf
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection