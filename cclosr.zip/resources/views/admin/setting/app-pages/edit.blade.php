@extends('admin.layouts.app')
@section('title', 'Edit App Page')
@push('page-style')
{{-- Page css files --}}
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/css/pages/app-user.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/editors/quill/katex.min.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/editors/quill/monokai-sublime.min.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/editors/quill/quill.snow.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/editors/quill/quill.bubble.css') }}">
@endpush
@section('content')
<nav aria-label="breadcrumb">
  <h2 class="content-header-title float-left mb-0">App Settings</h2>
    <ol class="breadcrumb breadcrumb-pipes">
        <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">home</a></li>
        <li class="breadcrumb-item"><a href="{{route('app-page.get.index')}}">App Page</a></li>
        <li class="breadcrumb-item active" aria-current="page">App Page Edit</li>
    </ol>
</nav>
{{-- App page edit start --}}
<section class="users-edit">
    <div class="card">
        <div class="card-header">
            <div class="card-title text-tp-primary">Edit App Page</div>
        </div>
        <div class="card-content">
            <div class="card-body">
                <div class="tab-content">
                    <div class="tab-pane active" id="account" aria-labelledby="account-tab" role="tabpanel">

                        <!-- users edit account form start -->
                        <form novalidate action="{{route('app-page.post.update')}}" method="post">
                            @csrf
                            <div class="row">
                              <div class="col-sm-12 col-md-6">
                                   <div class="form-group">
                                    <label for="name">Apge Title </label>
                                     <input type="text" name="title" value="{{$getResult->title}}" class="form-control" id="name">
                                    <span class="text-danger">{{ $errors->first('title') }}</span>
                                    </div>
                                </div>
                                 <div class="col-sm-12 col-md-6">
                                   <div class="form-group">
                                    <label for="type">Type</label>
                                     <input type="text" name="type" value="{{$getResult->type}}" class="form-control" id="type">
                                    <span class="text-danger">{{ $errors->first('type') }}</span>
                                    </div>
                                </div>
                              <div class="col-sm-12 col-md-12 full-editor " id="full-container">
                                        <label for="data-name">Page Content</label>
                                        <div class="editor" id="quill_editor">{!!$getResult->content!!}</div>
                                        <input type="hidden" id="quill_html" name="content" >
                                        <span class="text-danger">{{ $errors->first('content') }}</span>   
                              </div>
                               <input type="hidden" name="id" value="{{Crypt::encrypt($getResult->id)}}">
                                <div class="col-12 pt-4 d-flex flex-sm-row flex-column  mt-4">
                                    <button type="submit" class="btn btn-primary  glow mb-1 mb-sm-0 mr-0 mr-sm-1">Edit App Page</button>

                                </div>
                            </div>
                        </form>
                        <!-- users edit account form ends -->
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
{{-- App Page edit End --}}
@endsection
@push('vendor-script')
{{-- vendor js files --}}
<script src="{{ asset('app-assets/vendors/js/extensions/dropzone.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/editors/quill/katex.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/editors/quill/highlight.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/editors/quill/quill.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/extensions/jquery.steps.min.js') }}"></script>
@endpush
@push('page-script')
{{-- Page js files --}}
<script src="{{ asset('app-assets/js/scripts/ui/data-list-view.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/datatables.buttons.min.js') }}"></script>
<script src="{{ asset('app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js')}}"></script>
 <script src="{{ asset('app-assets/js/scripts/editors/editor-quill.js')}}"></script>
@endpush


