@extends('admin.layouts.app')
@section('title',__('Update App Version'))

@section('content')
 <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-left mb-0">Update App Version</h2>
                            <div class="breadcrumb-wrapper col-12">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{route('admin.get.home')}}">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active">App Version
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
      <div class="content-body">
         <section id="floating-label-layouts">
            <div class="row match-height">
               <div class="col-md-12 col-12">
                  <div class="card">
                      <div class="card-header">
                          @forelse ($version as $item)
                            <h3>{{$item->platform==0 ? 'Android':'iOS'}}</h3>
                            <p>Upcoming Version: {{$item->upcoming_version}}</p>
                            <p>Current Version: {{$item->current_version}}</p>
                          @empty
                              
                          @endforelse
                      </div>
            <div class="card-content">
                <div class="card-body">
                        <form method="POST" action="{{ route('version.post.store') }}">
                        @include('admin.include.form-message')
                        <div class="form-body">
                                <div class="#s">
                                   <div class="data-items pb-3">
                                      <div class="#">
                                            <div class="col-sm-12 form-group">
                                                    <label for="account-username">Choose Platform</label>
                                                    <select class="form-control" id="basicSelect" name="platform">
                                                           <option>Choose Platform/OS</option>
                                                            <option value="{{Crypt::encrypt('0')}}">Android</option>
                                                            <option value="{{Crypt::encrypt('1')}}">iOS</option>
                                                    </select>
                                     
                                             </div>
                                            <div class="col-sm-12 form-group">
                                                        <label for="account-username">Latest App Version Code</label>
                                                        <input type="text" name="current_version" class="form-control" id="account-username" placeholder="Current App Version of the app" required>
                                                
                                            </div>
                                            <div class="col-sm-12 form-group">
                                                        <label for="account-username">Upcoming App Version Code</label>
                                                        <input type="text" name="upcoming_version" class="form-control" id="account-username" placeholder="Upcoming App Version Code" required>
                                            </div>

                                     <div class="col-12">
                                       @csrf 
                                       <button type="submit" class="btn btn-primary mr-1 mb-1">Update</button>
                                       <button type="reset" class="btn btn-outline-warning mr-1 mb-1">Reset</button>
                                    </div>
                                 </div>
                              </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
