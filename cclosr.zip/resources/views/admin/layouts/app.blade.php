<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="author" content="Ccloser Admin">
    <title>@yield('title')</title>
    <link rel="apple-touch-icon" href="{{asset('app-assets/images/ico/apple-icon-120.png')}}">
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('images/logo/favicon.ico') }}">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600" rel="stylesheet">
    
        {{-- Include core + vendor Styles --}}
        @include('admin.include.styles')
        @notifyCss
</head>
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="vertical-layout vertical-menu-modern 2-columns  navbar-floating footer-static  " data-open="click" data-menu="vertical-menu-modern" data-col="2-columns">
  
    <!-- BEGIN: Header-->
    @include('admin.include.header')  
    <!-- END: Header-->
    <!-- BEGIN: Header-->
    @include('admin.include.sidebar')
    <!-- END: Header-->
    <!-- BEGIN: Main Menu-->
     <x:notify-messages />
    <div class="app-content content">
      <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
            <div class="content-wrapper">
                <div class="content-header row"></div>
                <div class="content-body">
                     @yield('content')
                </div>
            </div>
        </div>
    <!-- END: Content-->
 
    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <!-- BEGIN: Footer-->
    @include('admin.include.footer')
    <!-- END: Footer-->
         {{-- include default scripts --}}
         @notifyJs
         @include('admin.include.scripts')
        
         
</body>
</html>