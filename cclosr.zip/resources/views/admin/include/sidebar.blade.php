<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
        <div class="navbar-header">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item mr-auto"><a class="navbar-brand" href="{{route('admin.get.home')}}">
                        <div class="brand-logo">
                        </div>
                        <h2 class="brand-text mb-0">{{config('app.name')}}</h2>
                    </a></li>
            </ul>
        </div>
        <div class="shadow-bottom"></div>
        <div class="main-menu-content">
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class="{{ (request()->is('admin/home')) ? 'active' : '' }} nav-item"><a href="{{route('admin.get.home')}}"><i class="feather icon-home"></i><span class="menu-title" data-i18n="Dashboard">Dashboard</span></a>
                </li>
                <li class=" navigation-header"><span>Registered Users</span></li>
                <li class="{{ (request()->is('admin/user')) ? 'active' : '' }} nav-item"><a href="{{route('user.get.index')}}"><i class="feather icon-users"></i><span class="menu-title">All Users</span></a></li>
                 <li class="{{ (request()->is('admin/user/unverified-users')) ? 'active' : '' }} nav-item"><a href="{{route('user.get.unverified-users')}}"><i class="feather icon-alert-octagon"></i><span class="menu-title">Unverified Users</span></a></li>

                <li class=" navigation-header"><span>Features</span></li>
                <li class="nav-item {{ (request()->is('admin/template')) ? 'active' : '' }}"><a href="{{route('template.get.index')}}"><i class="feather icon-image"></i><span class="menu-title">Theme Template</span></a>
                </li>

                <li class="nav-item {{ (request()->is('admin/ccloser-request')) ? 'active' : '' }}"><a href="{{route('ccloserrequest.get.index')}}"><i class="feather icon-user-check"></i><span class="menu-title">Ccloser Request</span></a>
                </li>

                <li class="nav-item {{ (request()->is('admin/all-transactions')) ? 'active' : '' }}">
                    <a href="{{route('all-transactions')}}"><i class="feather icon-dollar-sign"></i><span class="menu-title">Transactions</span></a>
                </li>
                 <li class=" nav-item"><a href="#"><i class="feather icon-gift"></i><span class="menu-title" data-i18n="Icons">Referral</span></a>
                    <ul class="menu-content">
                        <li><a href="#"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Feather">Referral Used</span></a>
                        </li>
                        <li><a href="#"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Font Awesome">Referral Code</span></a>
                        </li>
                    </ul>
                </li>    
                <li class=" navigation-header"><span>Membership Area</span></li>
                <li class="nav-item {{ (request()->is('admin/membership-credits')) ? 'active' : '' }}">
                        <a href="{{route('membership-credits.get.index')}}"><i class="feather icon-award"></i><span class="menu-title">Membership Credits</span></a>
                    </li>
                 <li class="nav-item {{ (request()->is('admin/membership-plan')) ? 'active' : '' }}">
                    <a href="{{route('membership-plan.get.index')}}"><i class="feather icon-file-text"></i><span class="menu-title">Membership Plan</span></a>
                </li>
                 <li class=" navigation-header"><span>Report Management</span></li>
                <li class="nav-item {{ (request()->is('admin/report-management/monthly-transactions')) ? 'active' : '' }}">
                        <a href="{{route('monthly-transactions.get.index')}}"><i class="feather icon-activity"></i><span class="menu-title">Monthly Transactions</span></a>
                    </li>
               
                <li class=" navigation-header"><span>App Settings</span></li>

                <li class="nav-item {{ (request()->is('admin/app-page')) ? 'active' : '' }}">
                        <a href="{{route('app-page.get.index')}}">
                            <i class="ficon feather icon-folder"></i>
                            <span class="menu-title" data-i18n="Colors">App Pages</span>
                        </a>
                    </li>
                      <li class="nav-item {{ (request()->is('admin/notification')) ? 'active' : '' }}">
                        <a href="{{route('notification.get.index')}}">
                            <i class="ficon feather icon-bell"></i>
                            <span class="menu-title" data-i18n="Colors">Notification</span>
                        </a>
                    </li>

                    <li class="nav-item {{ (request()->is('admin/maintenance')) ? 'active' : '' }}">
                        <a href="{{route('maintenance.get.index')}}">
                            <i class="feather icon-settings"></i>
                            <span class="menu-title" data-i18n="Colors">Maintenance</span>
                        </a>
                    </li>

                    <li class="nav-item {{ (request()->is('admin/app-version')) ? 'active' : '' }}">
                            <a href="{{route('version.get.index')}}">
                                <i class="feather icon-alert-circle"></i>
                                <span class="menu-title" data-i18n="Colors">App version</span>
                            </a>
                    </li>
            </ul>
        </div>
    </div>