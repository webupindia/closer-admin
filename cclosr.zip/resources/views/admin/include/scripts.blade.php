<!-- BEGIN: Vendor JS-->
<script src="{{asset('app-assets/vendors/js/vendors.min.js')}}"></script>
<!-- BEGIN Vendor JS-->

<!-- BEGIN: Page Vendor JS-->
<script src="{{asset('app-assets/vendors/js/extensions/moment.min.js')}}"></script>
<script src="{{asset('app-assets/vendors/js/calendar/fullcalendar.min.js')}}"></script>
<script src="{{asset('app-assets/vendors/js/calendar/extensions/daygrid.min.js')}}"></script>
<script src="{{asset('app-assets/vendors/js/calendar/extensions/timegrid.min.js')}}"></script>
<script src="{{asset('app-assets/vendors/js/calendar/extensions/interactions.min.js')}}"></script>
<script src="{{asset('app-assets/vendors/js/pickers/pickadate/picker.js')}}"></script>
<script src="{{asset('app-assets/vendors/js/pickers/pickadate/picker.date.js')}}"></script>
<!-- END: Page Vendor JS-->

<!-- BEGIN: Theme JS-->
<script src="{{asset('app-assets/js/core/app-menu.js')}}"></script>
<script src="{{asset('app-assets/js/core/app.js')}}"></script>
<script src="{{asset('app-assets/js/scripts/components.js')}}"></script>
@notifyJs
<!-- END: Theme JS-->

<!-- BEGIN: Page JS-->
    @stack('vendor-script')
    @stack('page-script')
<!-- END: Page JS-->