@if(count($errors) > 0)
    <div class="row">
        <div class="col-md-12 error alert alert-danger ">
            <h4 class="alert-heading">Please resolve following errors: </h4>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{$error}}</li>
                @endforeach
            </ul>
        </div>
    </div>
@endif
