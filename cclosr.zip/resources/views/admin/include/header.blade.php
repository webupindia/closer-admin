<nav class="header-navbar navbar-expand-lg navbar navbar-with-menu floating-nav navbar-light navbar-shadow">
    <div class="navbar-wrapper">
        <div class="navbar-container content">
            <div class="navbar-collapse" id="navbar-mobile">
                <div class="mr-auto float-left bookmark-wrapper d-flex align-items-center">
                    <ul class="nav navbar-nav">
                        <li class="nav-item mobile-menu d-xl-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ficon feather icon-menu"></i></a></li>
                    </ul>
                </div>
                <ul class="nav navbar-nav float-right">
                    <li class="nav-item d-none d-lg-block"><a class="nav-link nav-link-expand"><i class="ficon feather icon-maximize"></i></a></li>
                    <li class="dropdown dropdown-notification nav-item"><a class="nav-link nav-link-label" href="#" data-toggle="dropdown"><i class="ficon feather icon-bell"></i><span class="badge badge-pill badge-primary badge-up">{{Auth::guard('admin')->user()->unreadNotifications->count()}}</span></a>
                        <ul class="dropdown-menu dropdown-menu-media dropdown-menu-right">
                            <li class="dropdown-menu-header">
                                <div class="dropdown-header m-0 p-2">
                                    <h3 class="white">{{Auth::guard('admin')->user()->unreadNotifications->count()}} New</h3><span class="notification-title">Notifications</span>
                                </div>
                            </li>
                            <li class="scrollable-container media-list">
                                    @foreach(Auth::guard('admin')->user()->unreadNotifications->take(6) as $notification)
                                    @if($notification->type=="App\Notifications\UserSignUpNotification")
                                      <a class="d-flex justify-content-between" href="javascript:void(0)">
                                          <div class="media d-flex align-items-start">
                                              <div class="media-left">
                                                  <i class="feather icon-plus font-medium-5 success"></i>
                                              </div>
                                              <div class="media-body">
                                                  <h6 class="success media-heading red darken-1">{{$notification->data['message']}}</h6>
                                              </div>
                                              <small>
                                                  <time class="media-meta">{{\Carbon\Carbon::parse($notification->created_at)->diffForHumans() }}</time>
                                              </small>
                                          </div>
                                      </a>
                                      @endif
                                      @endforeach
                              </li>
                            <li class="dropdown-menu-footer"><a class="dropdown-item p-1 text-center" href="{{route('notification.get.index')}}">Read all notifications</a></li>
                        </ul>
                    </li>
                    <li class="dropdown dropdown-user nav-item"><a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">
                            <div class="user-nav d-sm-flex d-none"><span class="user-name text-bold-600">Admin</span><span class="user-status">Available</span></div><span><img class="round" src="{{asset('app-assets/images/portrait/small/avatar-s-12.jpg')}}" alt="avatar" height="40" width="40"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="{{route('admin.get.profile')}}"><i class="feather icon-user"></i> Edit Profile</a>
                              <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="{{route('admin.get.logout')}}"><i class="feather icon-power"></i> Logout</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>