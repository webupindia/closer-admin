<?php
use Illuminate\Support\Facades\Route;
use Laravel\Socialite\Facades\Socialite;

/* Admin Routes Starts */
Route::get('admin/login', 'Admin\Auth\AuthenticationController@index')->name('admin.get.index');
Route::post('admin/login', 'Admin\Auth\AuthenticationController@postLogin')->name('admin.post.login');

Route::group(['namespace' => 'Admin','prefix' => 'admin','middleware' => ['admin']],function() {
    Route::get('home', 'HomeController@index')->name('admin.get.home');
     /* Logout User */
    Route::get('logout', 'Auth\AuthenticationController@getLogout')->name('admin.get.logout');
    /* Admin Profile */
    Route::get('profile', 'Auth\AuthenticationController@getProfile')->name('admin.get.profile');
    Route::post('profile/update', 'Auth\AuthenticationController@update')->name('profile.post.update');
    Route::post('password/update', 'Auth\AuthenticationController@changePassword')->name('password.post.update');
 
      /* -------------------User----------- */
    Route::prefix('user')->group(function () {
        Route::get('/', 'User\UserController@index')->name('user.get.index');
        Route::post('create', 'User\UserController@create')->name('user.get.create');
        Route::get('show/{id}', 'User\UserController@show')->name('user.get.show');
        Route::get('delete/{id}', 'User\UserController@destroy')->name('user.get.delete');
        Route::get('active/{id}', 'User\UserController@activeUser')->name('user.get.active');
        Route::get('inactive/{id}', 'User\UserController@deactiveUser')->name('user.get.inactive');
        Route::get('edit/{id}', 'User\UserController@edit')->name('user.get.edit');
        Route::post('update', 'User\UserController@update')->name('user.post.update');
        //Unverified Users
        Route::get('unverified-users', 'User\UserController@getUsers')->name('user.get.unverified-users'); 
        Route::get('verified/{id}', 'User\UserController@verifiedUser')->name('user.get.verified');
        Route::get('unverified/{id}', 'User\UserController@unverifiedUser')->name('user.get.unverified');
    });
    /* -------------------App Pages----------- */
    Route::group(['namespace' => 'AppSettings','prefix' => 'app-page'],function() {    
        Route::get('/', 'AppPagesController@index')->name('app-page.get.index');
        Route::post('create', 'AppPagesController@create')->name('app-page.post.create');
        Route::get('edit/{id}', 'AppPagesController@edit')->name('app-page.get.edit');
        Route::post('update', 'AppPagesController@update')->name('app-page.post.update');
        Route::get('delete/{id}', 'AppPagesController@destroy')->name('app-page.get.delete');
        Route::get('active/{id}', 'AppPagesController@active')->name('app-page.get.active');
        Route::get('inactive/{id}', 'AppPagesController@deactive')->name('app-page.get.inactive');
        
     });

    /* -------------------Notification----------- */
    Route::prefix('notification')->group(function () {
        Route::get('/', 'NotificationController@index')->name('notification.get.index');
        Route::get('read/{id}', 'NotificationController@markAsRead')->name('notification.get.read');
        Route::get('read-all', 'NotificationController@markAllAsRead')->name('notification.get.readAll');
     });

      /* -------------------Maintenance Mode----------- */
      Route::prefix('maintenance')->group(function () {
        Route::get('/', 'AppController@getMaintenance')->name('maintenance.get.index');
        Route::post('store', 'AppController@storeMaintenance')->name('maintenance.post.store');
    });

     /* -------------------Version Control----------- */
     Route::prefix('app-version')->group(function () {
      Route::get('/', 'AppController@getVersion')->name('version.get.index');
      Route::post('store', 'AppController@storeVersion')->name('version.post.store');
    });

     /*--------Theme Template-------*/
    Route::prefix('template')->group(function () {
        Route::get('/', 'Template\TemplateController@index')->name('template.get.index');
        Route::post('create', 'Template\TemplateController@create')->name('template.post.create');
        Route::get('delete/{id}', 'Template\TemplateController@destroy')->name('template.get.delete');
        Route::get('active/{id}', 'Template\TemplateController@activeTemplate')->name('template.get.active');
        Route::get('inactive/{id}', 'Template\TemplateController@deactiveTemplate')->name('template.get.inactive');
     }); 
     /*------Friends Request--------*/
    Route::view('friend-request', 'admin.friends-request.index')->name('friend-request');
     /*------Ccloser Request--------*/
     Route::prefix('ccloser-request')->group(function () {
        Route::get('/', 'CloserRequest\ImageRequestController@index')->name('ccloserrequest.get.index');
     });
     /*------Transactions--------*/
    Route::view('all-transactions', 'admin.transactions.index')->name('all-transactions');
    Route::view('show-transactions', 'admin.transactions.show')->name('show-transactions');

     /*------Membership Plan--------*/    
    Route::prefix('membership-plan')->group(function () {
        Route::get('/', 'Membership\MembershipPlanController@index')->name('membership-plan.get.index');
        Route::post('create', 'Membership\MembershipPlanController@create')->name('membership-plan.get.create');
        Route::get('edit/{id}', 'Membership\MembershipPlanController@edit')->name('membership-plan.get.edit');
        Route::post('update', 'Membership\MembershipPlanController@update')->name('membership-plan.post.update');
        Route::get('delete/{id}', 'Membership\MembershipPlanController@destroy')
        ->name('membership-plan.get.delete');
        Route::get('active/{id}', 'Membership\MembershipPlanController@active')->name('membership-plan.get.active');
        Route::get('inactive/{id}', 'Membership\MembershipPlanController@deactive')
        ->name('membership-plan.get.inactive');
     }); 

     /*--------Membership Credits-------*/
    Route::prefix('membership-credits')->group(function () {
        Route::get('/', 'Membership\MembershipCreditsController@index')->name('membership-credits.get.index');
        Route::get('show/{id}', 'Membership\MembershipCreditsController@show')->name('membership-credits.get.show');

     });
     
       /*--------Report Management -------*/
    Route::group(['namespace' => 'ReportManagement','prefix' => 'report-management'],function() {     
        Route::get('monthly-transactions', 'MonthlyTransactionController@index')->name('monthly-transactions.get.index');
     
     });
     
 
});