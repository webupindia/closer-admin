<?php
use Illuminate\Support\Facades\Route;

/* FrontEnd Routes Starts */
Route::get('/', function () {
    return view('frontend/index');
})->name('get.index');
// User Auth 
Route::group(['namespace' => 'Frontend\Auth'],function() {  
     /*=========Socialite===========*/  
    //Google Login
    Route::get('google', 'AuthenticationController@redirectToGoogle')->name('login.google');      
    Route::get('google/callback', 'AuthenticationController@handleGoogleCallback');                                                                                    
    //Facebook Login
    Route::get('facebook','AuthenticationController@redirectToFacebook')->name('login.facebook');      
    Route::get('facebook/callback', 'AuthenticationController@handleFacebookCallback');     

    Route::get('login', 'AuthenticationController@index')->name('user.get.login');
    Route::post('login', 'AuthenticationController@postLogin')->name('user.post.login');
    Route::get('logout', 'AuthenticationController@getLogout')->name('user.get.logout');
    Route::get('forget-password', 'AuthenticationController@forget')->name('user.get.forget-password');
    Route::post('forget-password', 'AuthenticationController@forget')->name('user.post.forget-password');
    Route::get('password-reset/{token}', 'AuthenticationController@reset')->name('password.reset');
    Route::post('password-reset/{token}', 'AuthenticationController@reset')->name('user.post.password.reset');
});    

Route::group(['namespace' => 'Frontend','middleware' => ['auth']],function() {
    Route::get('/home', function () {
        return view('frontend/index');
    });
    //checkout
    Route::get('checkout/{id}', 'Checkout\CheckoutController@index')->name('get.checkout.index');
    // Payment Success And Failure
    Route::prefix('payment')->group(function () {
    // for Initiate the order
    Route::post('payment-initiate-request','Payment\PaymentController@Initiate')->name('Initiate');

    // for Payment complete
    Route::post('payment','Payment\PaymentController@Complete')->name('payment.complete');     
    Route::view('success', 'frontend.payment.success')->name('payment.view.success');
    Route::view('failure', 'frontend.payment.failure')->name('payment.view.failure');
}); 
});    
// All Pages
//  Static Pages 
Route::group(['namespace' => 'Frontend\StaticPage'],function() { 
    Route::get('legal/{slug}', 'StaticPagesController@StaticSpecificData')->name('get.static.page');
});  

Route::get('membership-plan', 'Frontend\Membership\MembershipPlanController@index')->name('get.membership.index');

// Contact Us
Route::group(['namespace' => 'Frontend\Contact'],function() { 
    Route::get('contact-us', 'ContactController@index')->name('get.contact.index');
    Route::post('contact-us', 'ContactController@sendMailContact')->name('post.contact.sendMailContact');
});   

